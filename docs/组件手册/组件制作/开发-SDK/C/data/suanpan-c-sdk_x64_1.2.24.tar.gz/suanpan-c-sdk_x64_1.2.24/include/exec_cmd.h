#ifndef __EXEC_CMD_H__
#define __EXEC_CMD_H__

#include "sdk_os.h"


/**
* 简单执行一个脚本命令
* @param[in]  cmd 命令字符串
* @retval  0
*/
__EXPORT int exec_cmd(char *cmd);

/**
* 执行一个脚本命令并且得到返回数据，此函数线程不安全
* @param[in]  cmd 命令字符串
* @retval  返回结果数据
*/
__EXPORT char *exec_cmd_with_result(char *cmd);

/**
* 执行一个脚本命令并且得到返回数据，此函数线程安全
* @param[in]  cmd 命令字符串
* @param[in]  max_buffer 返回最大的数据存储
* @retval  返回结果数据
*/
__EXPORT char * exec_cmd_with_result2(char *cmd, int max_buffer);

#endif