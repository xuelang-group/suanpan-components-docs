
#include "sdk_utility.h" //包含LOGD,os_sleep等函数，用户可以不使用
#include "sp_env.h"

#define TAG "TEST_ENV"

int test_env()
{
	LOGD(TAG, "test function starts");
	char *run_mode = sp_get_env("--run_mode"); //右面板参数run_mode，这里读入
	if (run_mode) {
		LOGD(TAG, "Run mode=%s", run_mode); //打印run_mode设置
		os_free(run_mode);
	} else {
		LOGE(TAG, "Run mode undefined!");
	}

	char *color = sp_get_env("--color"); //右面板参数run_mode，这里读入
	if (color) {
		LOGD(TAG, "Color =%s", color); //打印run_mode设置
		os_free(color);
	} else {
		LOGE(TAG, "Color undefined!");
	}

	while (1) {
		os_sleep(1);
	}
}
