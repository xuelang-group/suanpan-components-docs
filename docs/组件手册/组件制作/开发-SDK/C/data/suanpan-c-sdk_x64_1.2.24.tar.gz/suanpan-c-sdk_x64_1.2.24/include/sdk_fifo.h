#ifndef __SDK_FIFO_H__
#define __SDK_FIFO_H__

typedef void * SDK_FiFo;

#include "sdk_os.h"

__EXPORT SDK_FiFo sdk_fifo_create(int count, int size);
__EXPORT int sdk_fifo_add(SDK_FiFo fifo, const void * item);
__EXPORT int sdk_fifo_get(SDK_FiFo fifo, void * item);
__EXPORT int sdk_fifo_is_full(SDK_FiFo fifo);
__EXPORT int sdk_fifo_is_empty(SDK_FiFo fifo);
__EXPORT SDK_FiFo  sdk_fifo_copy(SDK_FiFo fifo);
__EXPORT int sdk_fifo_destroy(SDK_FiFo fifo);
__EXPORT void sdk_fifo_info(SDK_FiFo fifo);

#endif

