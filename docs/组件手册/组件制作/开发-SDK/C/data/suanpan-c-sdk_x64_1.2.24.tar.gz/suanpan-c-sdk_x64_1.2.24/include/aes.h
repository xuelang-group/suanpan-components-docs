#ifndef __AES_H__
#define __AES_H__

int aes_encrypt_ecb(const unsigned char* Key, const unsigned char KeyLen, unsigned char* PlainContent, unsigned char* CipherContent, const int BlockCount);
int aes_decrypt_ecb(const unsigned char* Key, const unsigned char KeyLen, unsigned char* CipherContent, unsigned char* PlainContent, const int BlockCount);

#endif