#ifndef __SP_ENV_H__
#define __SP_ENV_H__

#include "sdk_os.h"

/** 
* 得到环境变量值. 内存需要被释放
* @param[in]   config_name 配置名，比如--enable-abc. 
* @retval  char*  配置值 
* @retval  NULL   错误  
*/
__EXPORT char *sp_get_env(char *config_name);
__EXPORT void sp_rpc_start_dll(char *oss_package_path, char *function_name);
__EXPORT int suanpan_cloud_valid();
#define suanpan_valid suanpan_cloud_valid

#endif
