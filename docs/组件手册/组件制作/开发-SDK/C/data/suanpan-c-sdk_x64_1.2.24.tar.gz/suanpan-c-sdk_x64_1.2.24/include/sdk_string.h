
#ifndef __SDK_STRING_H__
#define __SDK_STRING_H__

#include "sdk_os.h"

/**
* 字符串编码转换，此函数依赖iconv
* @param[in]  from_charset 源编码，命令iconv -l查看列表
* @param[in]  to_charset 目标编码，命令iconv -l查看列表
* @param[in]  inbuf 输入字符串
* @param[in]  inlen 输入字符串长度
* @param[out]  outbuf 输出字符串
* @param[in]  outlen 输出字符串长度
* @retval  0 成功
*/
__EXPORT int sdk_code_convert(char *from_charset, char *to_charset,
                char *inbuf, int inlen, char *outbuf, int outlen);

/**
* 将字符串str里面所有的的sub替换为字符串replace，返回的字符串是一个新的内存，需要释放。
* @param[in]  str 源字符串
* @param[in]  sub 需要替换的字符串
* @param[in]  replace 需要替换成的字符串
* @return  字符串结果
*/
__EXPORT char *sdk_str_replace(const char *str, const char *sub, const char *replace);

/**
* Convert integer to string
* @param[in]  value     A 64-bit number to convert
* @param[in]  str       Destination buffer; should be 66 characters long for radix2, 24 - radix8, 22 - radix10, 18 - radix16.
* @param[in]  radix     Radix must be in range -36 .. 36. Negative values used for signed numbers.
* @return  字符串结果
*/
__EXPORT char* sdk_str_itoa(long long  value, char str[], int radix);

/**
* Convert integer to string，非线程安全
* @param[in]  value     number to convert
* @return  字符串结果
*/
__EXPORT char* sdk_itoa(int value);

#endif