#ifndef __SDK_BASE64__H__
#define __SDK_BASE64__H__

#include "sdk_os.h"

/**
* 将字符串编码为base64字符串  TBD：编码二进制
* @param[in]  sourcedata 源字符串
* @param[in]  base64 目标base64字符串， base64大小为n * 4 / 3，所以传入2倍字符串大小内存充分满足
* @retval  0
*/
__EXPORT int sdk_base64_encode(const unsigned char * sourcedata, char * base64);

/**
* 将base64字符串解码为普通字符串  TBD：解码二进制
* @param[in]  base64 源base64字符串
* @param[in]  dedata 目标字符串，传入源base64字符串大小可以充分满足。
* @retval  0
*/
__EXPORT int sdk_base64_decode(const char * base64, unsigned char * dedata);


#endif