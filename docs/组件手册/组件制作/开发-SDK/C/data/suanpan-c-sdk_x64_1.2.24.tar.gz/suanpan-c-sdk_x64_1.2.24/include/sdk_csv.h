#ifndef _SDK_CSV_H
#define _SDK_CSV_H



/** 
* @file         sdk_csvh 
* @brief        表格操作功能. 
* @details      提供一个csv表格的数据结构，可以当作简单的数据库缓存和csv导入导出的功能
*/  

#include <stdlib.h>
#include <stdio.h>
#include "sdk_os.h"

typedef struct CSV_FIELD {
        char *text;
        size_t length;
} CSV_FIELD;

typedef struct CSV_BUFFER {
        CSV_FIELD ***field;//表格的行列数据指针的指针
        size_t rows;
        size_t *width; //表格每一行的宽度，每一行的宽度可能不一样
        char field_delim;
        char text_delim;
        struct os_mutex mutex;
} CSV_BUFFER;


/** 
* 创建一个csv实例，创建完之后，表格是0x0的
* @retval  CSV_BUFFER* csv句柄 
*/
__EXPORT CSV_BUFFER *csv_create_buffer();

/** 
* 删除一个CSV实例 
* @param[in]  buffer csv句柄
* @retval  void 
*/
__EXPORT void csv_destroy_buffer(CSV_BUFFER *buffer);

/** 
* 复制一个CSV实例，深拷贝
* @param[in]  src csv句柄
* @retval  CSV_BUFFER* 拷贝后的csv句柄 
*/
__EXPORT CSV_BUFFER * csv_dup_buffer(CSV_BUFFER *src);

/** 
* 对一个csv对象加锁
* @param[in]  buffer csv句柄
* @retval  void 
*/
__EXPORT void csv_lock(CSV_BUFFER *buffer); //对本对象加锁

/** 
* 对一个csv对象解锁
* @param[in]  buffer csv句柄
* @retval  void 
*/
__EXPORT void csv_unlock(CSV_BUFFER *buffer); //对本对象解锁

/** 
* 从csv文件读取到csv数据结构中,  注意只支持Unix格式(结尾为\n)，参考csv_load_buffer
* @param[in]  buffer csv数据结构的句柄，用之前需要被创建
* @param[in]  file_name csv文件的文件名
* @retval  0 成功
* @retval  1 文件无法找到
* @retval  2 内存错误
*/
__EXPORT int csv_load(CSV_BUFFER *buffer, char *file_name);

/** 
* 将csv的缓存保存到文件，如果文件已经存在，会被覆盖，保存格式为unix的\n格式。
* @param[in]  buffer csv数据结构的句柄，用之前需要被创建
* @param[in]  file_name csv文件的文件名
* @retval  0 成功
* @retval  1 写失败（文件名错误或者无法访问）
*/
__EXPORT int csv_save(char *file_name, CSV_BUFFER *buffer);

/** 
* 从 buffer 读取到csv数据结构中， 注意只支持Unix格式，结尾为\n
* 需要支持Windows的\r\n格式，需要使用：sdk_str_replace(file_content, "\r\n", "\n");
* @param[in]  buffer csv数据结构的句柄，用之前需要被创建
* @param[in]  file_name csv缓存
* @retval  0 成功
* @retval  -1 错误
*/
__EXPORT int csv_load_buffer(CSV_BUFFER *buffer, char *in_buffer);

/** 
* 将csv的缓存保存到buffer，如果文件已经存在，会被覆盖
* @param[in]  buffer csv数据结构的句柄，用之前需要被创建
* @param[in]  max_size 外部给予的大小
* @retval  0 成功
* @retval  -1 失败
*/
__EXPORT char* csv_save_buffer(CSV_BUFFER *buffer, int max_size);


/** 
* 将csv的缓存打印出来
* @param[in]  buffer csv数据结构的句柄，用之前需要被创建
*/
__EXPORT void csv_print_buffer(CSV_BUFFER *buffer);


/** 
* 将csv的某一行拷贝，源表和目标表可以是相同，也可以是不同的
* @param[in]  dest 目标表的句柄
* @param[in]  dest_row 目标表的第几行
* @param[in]  src 源表的句柄
* @param[in]  src_row 源表的第几行
* @retval  0 成功
* @retval  1 源表的这一行不存在
*/
__EXPORT int csv_copy_row(CSV_BUFFER *dest, int dest_row,
                        CSV_BUFFER *src, int src_row);

/** 
* 将csv的某一行的某一列拷贝，源表和目标表可以是相同，也可以是不同的
* @param[in]  dest 目标表的句柄
* @param[in]  dest_row 目标表的第几行
* @param[in]  dest_entry 目标表的第几列
* @param[in]  src 源表的句柄
* @param[in]  src_row 源表的第几行
* @param[in]  source_entry 源表的第几列
* @retval  0 成功
* @retval  1 内存错误
*/
__EXPORT int csv_copy_field(CSV_BUFFER *dest, int dest_row, int dest_entry,
                   CSV_BUFFER *source, int source_row, int source_entry);

/** 
* 将csv的某一行的某一列拷贝到一个buffer
* @param[in]  dest 目标buffer
* @param[in]  dest_len 目标buffer的长度
* @param[in]  dest_entry 目标表的第几列
* @param[in]  src 源表的句柄
* @param[in]  row 源表的第几行
* @param[in]  entry 源表的第几列
* @retval  0 成功
* @retval  1 the entry was trucated to fit the string
* @retval  2 the request cell was empty (or does not exist)
* @retval  3 the length given was 0
*/
__EXPORT int csv_get_field(char *dest, size_t dest_len,
        CSV_BUFFER *src, size_t row, size_t entry);


/** 
* 在表中某一列找一个字符串在第几行
* @param[in]  dest 目标buffer
* @param[in]  field 第几列
* @param[in]  field_str 字符串
* @retval  >=0 成功
* @retval  -1 找不到
*/
__EXPORT int csv_find_row_by_field(CSV_BUFFER *buffer, int field, char* field_str);

/** 
* 得到某一单元格的内存指针, 外面不用释放指针
* @param[in]  src 目标buffer
* @param[in]  row 第几行
* @param[in]  entry 第几列
* @retval  char* 内存指针
* @retval  NULL 找不到
*/
__EXPORT char* csv_get_field_ptr(CSV_BUFFER *src, size_t row, size_t entry);

/** 
* 清空某个单元格为 '\0'
* @param[in]  src 目标buffer
* @param[in]  row 第几行
* @param[in]  entry 第几列
* @retval  0 成功
* @retval  其他 失败
*/
__EXPORT int csv_clear_field(CSV_BUFFER *buffer, size_t row, size_t entry);

/*
* 清空某一行，只留一个单元格为'\0'
* @param[in]  src 目标buffer
* @param[in]  row 第几行
* @retval  0 成功
* @retval  1 memory allocation falirure (note this function only reduces memory used,
 so reallocation should never fail)
*/
__EXPORT int csv_clear_row(CSV_BUFFER *buffer, size_t row);

/*
* 彻底清空某一行，单元格全部删除
* @param[in]  src 目标buffer
* @param[in]  row 第几行
* @retval  0 成功
* @retval  1 memory allocation falirure (note this function only reduces memory used,
 so reallocation should never fail)
*/
__EXPORT int csv_remove_row(CSV_BUFFER *buffer, size_t row);

/*
* 彻底清空表格里面的所有数据
* @param[in]  src 目标buffer
* @retval  0 成功
*/
__EXPORT int csv_remove_all_row(CSV_BUFFER *buffer);

/*
* 设置字符串分割，默认为 "
* @param[in]  src 目标buffer
* @param[in]  new_delim 分割
* @retval  void
*/
__EXPORT void csv_set_text_delim(CSV_BUFFER *buffer, char new_delim);

/*
* 设置单元格分割，默认为 ,
* @param[in]  src 目标buffer
* @param[in]  new_delim 分割
* @retval  void
*/
__EXPORT void csv_set_field_delim(CSV_BUFFER *buffer, char new_delim);

/*
* 得到表格的行数
* @param[in]  src 目标buffer
* @retval  int 行数
*/
__EXPORT int csv_get_height(CSV_BUFFER *buffer);

/*
* 得到表格某一行的列数
* @param[in]  src 目标buffer
* @param[in]  row 第几行
* @retval  int 列数
*/
__EXPORT int csv_get_width(CSV_BUFFER *bufer, size_t row);

/*
* 得到表格某一单元格的大小
* @param[in]  src 目标buffer
* @param[in]  row 第几行
* @param[in]  entry 第几列
* @retval  int 大小
*/
__EXPORT int csv_get_field_length(CSV_BUFFER *buffer, size_t row, size_t entry);

/*
* 覆盖一个单元格
* @param[in]  src 目标buffer
* @param[in]  row 第几行
* @param[in]  entry 第几列
* @param[in]  field 要覆盖的数据
* @retval  0 成功
* @retval  1 失败
*/
__EXPORT int csv_set_field(CSV_BUFFER *buffer, size_t row, size_t entry, char *field);


/*
* 插入一个单元格
* @param[in]  src 目标buffer
* @param[in]  row 第几行
* @param[in]  entry 第几列
* @param[in]  field 要插入的数据
* @retval  0 成功
*/
__EXPORT int csv_insert_field(CSV_BUFFER *buffer, size_t row, size_t entry,
        char *field);

#endif /* CSV_H_ */
