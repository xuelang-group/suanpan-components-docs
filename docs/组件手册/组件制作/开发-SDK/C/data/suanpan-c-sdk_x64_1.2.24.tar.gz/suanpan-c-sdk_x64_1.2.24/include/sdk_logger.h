/** 
* @file         sdk_log.h 
* @brief        日志输出功能. 
* @details  当用户使用时，需要在文件定义一个TAG变量。然后使用LOGD(TAG, "ABC=%s", "DEF");的格式
*/  

#ifndef _SDK_LOG_H__
#define _SDK_LOG_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <string.h>

#if defined (_WIN32)
    #define __EXPORT __declspec(dllexport) 
#else
    #define __EXPORT
#endif

typedef enum {
    SDK_LOG_LEVEL_NONE = 0,
    SDK_LOG_LEVEL_FATAL,
    SDK_LOG_LEVEL_ERROR,
    SDK_LOG_LEVEL_WARN,
    SDK_LOG_LEVEL_INFO,
    SDK_LOG_LEVEL_DEBUG,
    SDK_LOG_LEVEL_VERBOSE,
    LOG_MAX
} sdk_log_level_t;

/** 
* 下面两个API不需要调用 
*/
__EXPORT int sdk_log_func(const char *tag, int log_level, const char *fmt, ...);
__EXPORT int sdk_log_hexdump(const char *tag, char *buffer, int len);

/** 
* 设置SDK的日志级别 
* @param[in]  log_level 级别，级别从sdk_log_level_t里面选择
* @retval  void 
*/
__EXPORT void sdk_set_log_level(int log_level);

/** 
* 得到SDK的日志级别 
* @param[in]  void
* @retval  int  日志级别，级别的范围是 sdk_log_level_t里面选择
*/
__EXPORT int sdk_get_log_level(void);

/** 
* 设置内存日志缓存，使用LOGD，LOGE等API产生的日志都会同时输出到日志文件中 
* @param[in]  enable 使能日志文件
* @param[in]  max_size 日志文件的最大大小，默认10MB
* @retval  void 
*/
__EXPORT void sdk_set_log_buffer(int enable, int max_size);

/** 
* 清除日志缓存
* @param[in]  void
* @retval  size 文件大小
* @retval  0   成功  
* @retval  -1   失败  
*/
__EXPORT int sdk_clear_log_buffer();

/** 
* 得到日志缓存
* @param[in]  void
* @retval  char* 内存中的缓存，需要用户得到之后在外部释放
*/
__EXPORT char* sdk_get_log_buffer();

/** 
* 保存缓存到云存储
* @param[in]  filename 文件名
* @retval  0 成功
* @retval  -1 失败
*/
__EXPORT int sdk_save_log_buffer(char *filename);


/** 
* 将log持续记录到日志文件
* @param[in]  file 文件名
* @retval  0 成功
* @retval  -1 失败
*/
__EXPORT int sdk_set_log_file(char *file);


/** 
* 日志接口，使用样例： 
*
* #define TAG "HTTPSERVER"
* LOGD(TAG, "Hello World Success");
* LOGE(TAG, "Start Failed");
* LOGW(TAG, "This is a warning");
*/
#define LOG_HEX(tag, buf, len)      sdk_log_hexdump(tag, buf, len)
#define LOGF(tag, format, ...)      sdk_log_func(tag, SDK_LOG_LEVEL_FATAL, format"\n",##__VA_ARGS__)
#define LOGE(tag, format, ...)      sdk_log_func(tag, SDK_LOG_LEVEL_ERROR, format"\n",##__VA_ARGS__)
#define LOGW(tag, format, ...)      sdk_log_func(tag, SDK_LOG_LEVEL_WARN, format"\n",##__VA_ARGS__)
#define LOGI(tag, format, ...)      sdk_log_func(tag, SDK_LOG_LEVEL_INFO, format"\n",##__VA_ARGS__)
#define LOGD(tag, format, ...)      sdk_log_func(tag, SDK_LOG_LEVEL_DEBUG, format"\n",##__VA_ARGS__)
#define LOGV(tag, format, ...)      sdk_log_func(tag, SDK_LOG_LEVEL_VERBOSE, format"\n",##__VA_ARGS__)

#ifdef __cplusplus
}
#endif

#endif

