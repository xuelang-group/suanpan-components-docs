#ifndef __PARSE_ARGV_H__
#define __PARSE_ARGV_H__

#include "sdk_os.h"

#include "sdk_utility.h"

/**
* 将一个命令行解析
* @param[in]  str 源字符串，如-a 1 -b 3 -c 3
* @param[out]  argc 返回的参数数量
* @param[out]  argv 返回的参数内存
* @param[in]  number 指定argv可以存储的argc数量。
* @retval  成功 返回0
* @retval  失败 返回-1
*/
__EXPORT int parse_argv(char* str, int* argc, char** argv, int number);

#endif