
#include "sdk_utility.h" //包含LOGD,os_sleep等函数，用户可以不使用
#include "sp_mq.h"

#define TAG "TEST_MQ"

//被动接收
void mq_callback(Sp_mq mq, 
				char *input_port_name, 
				char *input_data, 
            	char *uuid,
				void *user)
{
	LOGD(TAG, "Received %s from %s", input_data, input_port_name);

	char buffer[1024] = {0};
	sprintf(buffer, "data for out1[%s]", input_data);
	sp_mq_send(mq, "out1", buffer, uuid);
	sprintf(buffer, "data for out2[%s]", input_data);
	sp_mq_send(mq, "out2", buffer, uuid);	

}

void mq_test()
{
	Sp_mq mq =  sp_mq_init();  //初始化一个mq
	sp_mq_register_callback(mq, mq_callback, NULL); //注册mq回调

	char message[100] = {0};
	int i = 0;

	//主动发送
	while (1) {
		LOGD(TAG, "Trigger");
		sprintf(message, "csdk message out1 id=%d", i++); //每次发送的消息都不一样
		sp_mq_send(mq, "out1", message, NULL); //向mq发送消息
		sprintf(message, "csdk message out2 id=%d", i++); //每次发送的消息都不一样
		sp_mq_send(mq, "out2", message, NULL); //向mq发送消息
		os_sleep(10);
	}
}


int test_mq()
{

	LOGD(TAG, "test function starts");

	mq_test();
}
