/**         
 * @file sp_storage.h                 
 * @brief 算盘存储接口。将数据保存到云硬盘的普通文件区域或者云硬盘的配置文件区域
 * 
 */
#ifndef __SP_STORAE__
#define __SP_STORAE__

#include "sdk_os.h"

typedef void *SP_Storage;

/** 
* 初始化算盘存储. 
* @param[out]   SP_Storage 返回的配置文件句柄. 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT SP_Storage sp_storage_init();

/** 
* 析构算盘存储. 
* @param[out]   SP_Storage 返回的配置文件句柄. 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int sp_storage_deinit(SP_Storage storage);


////////////////////// Config file API///////////////////////////////
/** 
* 保存配置文件到算盘的配置文件区域，当组件被释放的时候，此文件不会被删除. 
* @param[in]   hdl 算盘存储句柄. 
* @param[in]   port_id 端口名称，比如out1，如果存储不绑定端口，传NULL. 
* @param[in]   file_name 存储配置文件名称. 
* @param[in]   buffer 存储的文件内容. 
* @param[in]   size 存储的文件大小 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int sp_config_save(SP_Storage hdl,
                    char *port_id, char *file_name,
                    char *buffer, int size);

/** 
* 从算盘的配置文件区域加载配置文件内容
* @param[in]   hdl 算盘存储句柄. 
* @param[in]   port_id 端口名称，比如out1，如果存储不绑定端口，传NULL. 
* @param[in]   file_name 存储配置文件名称. 
* @param[in]   buffer 返回的存储的文件内容，外部需要释放
* @param[in]   size 返回的存储的文件大小 
* @retval  0  成功 
* @retval  -1  错误，一般是因为文件不存在
*/
__EXPORT int sp_config_load(SP_Storage hdl,
                      char *port_id, char *file_name,
                        char **buffer, int *size);


/** 
* 从算盘的配置文件区域删除某一个配置文件
* @param[in]   hdl 算盘存储句柄. 
* @param[in]   port_id 端口名称，比如out1，如果存储不绑定端口，传NULL. 
* @param[in]   file_name 存储配置文件名称. 
* @retval  0  成功 
* @retval  -1  错误，一般是因为文件不存在
*/
__EXPORT int sp_config_delete(SP_Storage hdl,
                      char *port_id, char *file_name);                   
////////////////////////////////////////////////////////////////////


//////////////////////////////temp file API//////////////////////////////////////
/** 
* 保存文件到算盘的临时文件存储区域，当组件被释放或者下一个节点调用接口删除的时候，此文件会被删除. 
* @param[in]   hdl 算盘存储句柄. 
* @param[in]   port_id 端口名称，比如out1，如果存储不绑定端口，传NULL. 
* @param[in]   file_name 存储配置文件名称. 
* @param[in]   buffer 存储的文件内容. 
* @param[in]   size 存储的文件大小 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT char* sp_tmp_file_save(SP_Storage hdl,
                    char *request_id,  char *port_id,
                    char *file_name, char *buffer,
                    int size);

/** 
* 从算盘的临时文件存储区域加载文件内容
* @param[in]   hdl 算盘存储句柄. 
* @param[in]   url 文件的地址. 
* @param[in]   outbuffer 返回的存储的文件内容，外部需要释放
* @param[in]   bufferlen 返回的存储的文件大小 
* @retval  0  成功 
* @retval  -1  错误，一般是因为文件不存在
*/
__EXPORT int sp_tmp_file_load(SP_Storage hdl,
            char *url, char *filename, char **outbuffer, int *bufferlen);

/** 
* 从算盘的临时文件存储删除文件内容
* @param[in]   hdl 算盘存储句柄. 
* @param[in]   url 文件的地址. 
* @retval  0  成功 
* @retval  -1  错误，一般是因为文件不存在
*/
__EXPORT int sp_tmp_file_delete(SP_Storage hdl, char *url, char *filename);
////////////////////////////////////////////////////////////////////



#endif