#ifndef __HTTP_CLIENT__
#define __HTTP_CLIENT__


#include "sdk_os.h"


//这些API部分设计不合理，需要调整下。比如int buffer_size不应该传入，应该自动分配内存。

//不建议使用此API
__EXPORT char *SDK_HTTP_Client_Post(char *domain, int port, char *url, char *post_data);

//建议使用新的API
__EXPORT char *SDK_HTTP_Client_Post2(char *domain, int port,
                    char *url, char *post_data, int buffer_size, int timeout); //buffer_size 是内部的缓冲大小。timeout是秒

__EXPORT int SDK_HTTP_Client_Get_Data(char* domain, int port, char* suburl, int timeout, char** ret_str, int* ret_len);
__EXPORT int SDK_HTTP_Client_Get_File(char *domain, int port, char *suburl, char *filename, int timeout);
__EXPORT int SDK_HTTP_Client_Get_File2(char *url, char *filename, int timeout);

#endif