
#ifndef __SDK_TIMER2_H__
#define __SDK_TIMER2_H__

#include "sdk_os.h"

typedef void *Timer2_Handle;
typedef void *Timer2_Action;

typedef void (*timed_action_handler)(int interval_ms, void*user);

/**
* 退出timer, 初始化一个timer，精度100ms
* @retval  Timer2_Handle 用来存储时间句柄
*/
__EXPORT Timer2_Handle sdk_timer2_init();

/**
* 增加一个定期调用的回调函数
* 这里的每一个timerfd是一个open的文件，默认的ulimit -n是1024，会导致报错errno24 too many opened filed
* 可以通过/proc/xxx/fd 查看文件数量。放大：ulimit -n 10240
* @param[in]  hdl 用来存储时间句柄
* @param[in]  ms 时间间隔
* @param[in]  handler 回调函数
* @param[in]  arg 回调参数
* @retval  Timer2_Action 用来存储时间回调行为
*/
__EXPORT Timer2_Action sdk_timer2_add_handler(Timer2_Handle hdl,  int ms,
                            timed_action_handler handler,  void* arg);

/**
* 删除这个定期调用的回调函数
* @param[in]  hdl 用来存储时间句柄
* @param[in]  action 用来存储时间回调行为
* @retval  返回0
*/
__EXPORT int sdk_timer2_del_handler(Timer2_Handle hdl, Timer2_Action action);

/**
* 退出timer, 需要先删除回调函数才能退出。
* @param[in]  hdl 用来存储时间句柄
* @retval  返回0
*/
__EXPORT int sdk_timer2_deinit(Timer2_Handle hdl);

#endif
