#ifndef __KAFKA_CONSUMER__
#define __KAFKA_CONSUMER__


typedef void(*kafka_consumer_callback)(char *topic, u32 partition, u64 offset,  
                        char *key, int key_len, char* payload, int payload_len);

void* kafka_consumer_new(char* brokers, char *groupid, char **topics, int topic_cnt, kafka_consumer_callback cb);
int kafka_consumer_start(void *handle);
int kafka_consumer_destroy(void *handle);



#endif