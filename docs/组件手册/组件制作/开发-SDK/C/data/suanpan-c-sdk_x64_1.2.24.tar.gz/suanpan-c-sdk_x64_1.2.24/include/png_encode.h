#ifndef __PNG_ENCODE_H__
#define __PNG_ENCODE_H__

#include "sdk_os.h"

__EXPORT int BMP_To_PNG(char *rgba, char* out_buffer, int width, int height);



#endif