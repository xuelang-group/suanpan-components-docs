#ifndef __XL_REDIS__
#define __XL_REDIS__

void* xl_redis_connect(char *hostname, int port);
int xl_redis_disconnect(void* hdl);
int xl_redis_read_binary(void *hdl, char *key, char **value, int *value_len);
char* xl_redis_read(void *hdl, char *key);
int xl_redis_write_binary(void *hdl, char *key, char *value, int value_len);
int xl_redis_write(void *hdl, char *key, char *value);
int xl_redis_delete(void *hdl, char *key);

#endif