
#ifndef __OS__H_
#define __OS__H_



#if defined (_WIN32)
    #include "winsock2.h"
    #include "windows.h"
    //#include <fstream.h>
    #include <time.h>
    #include <stdlib.h>
    #include <stdio.h>
    #include <process.h>

    #define __EXPORT __declspec(dllexport) 
    #define THREAD_EXIT 0


    //typedef DWORD (WINAPI* os_thread_function)(void*);
    typedef void (*os_thread_function) (void *);
    #define OS_THREAD_EXIT do { _endthread(); return; } while (0);
    #define OS_THREAD_RET static void

    struct os_mutex {
        HANDLE lock; 
    };

    #define strdup _strdup

    #ifndef __MINGW32__
    struct timezone {
        int tz_minuteswest;
        int tz_dsttime;
    };
    #endif

#elif defined(__unix__ ) || defined(__linux__)
    #define __EXPORT
    #define THREAD_EXIT NULL
    #define OS_THREAD_EXIT do {  return NULL; } while (0);
    #define OS_THREAD_RET static void*
    #define _XOPEN_SOURCE 700

    #ifndef _DEFAULT_SOURCE
    #define _DEFAULT_SOURCE
    #endif
    // # warning "_BSD_SOURCE and _SVID_SOURCE are deprecated, use _DEFAULT_SOURCE"
    //#define _BSD_SOURCE  //for usleep

    #include <fcntl.h>
    #include <poll.h>
    #include <signal.h>
    #include <unistd.h>
    #include <linux/input.h>
    #include <stdio.h>
    #include <stdint.h>
    #include <string.h>
    #include <stdarg.h>
    #include <time.h>
    #include <stdlib.h>
    #include <sys/time.h>

    #include <sys/time.h>
    #include <sys/sysinfo.h>
    #include <sys/types.h>
    #include <sys/socket.h>
    #include <sys/ioctl.h>
    #include <sys/types.h>
    #include <sys/wait.h>
    #include <sys/stat.h>
    #include <sys/select.h>
    #include <sys/ipc.h>
    #include <sys/msg.h>

    #include <unistd.h>
    #include <netinet/in.h>
    #include <net/if.h>
    #include <stdarg.h>
    #include <stdlib.h>
    #include <syslog.h>
    #include <assert.h>
    #include <string.h>
    #include <errno.h>
    #include <fcntl.h>
    #include <arpa/inet.h>
    #include <netdb.h>

    #define __USE_GNU
    #include <sched.h>
    #include <pthread.h>
    #include <time.h>
    #include <stdarg.h>
    #include <memory.h>
    #include <stdio.h>

    struct os_mutex {
        pthread_mutex_t lock;
    };
    
    typedef void * (*os_thread_function)(void *arg);


#elif defined(__APPLE__ )
    #error "not support OSX!"

#endif

typedef void (*os_service_func)(int argc, char** argv);

//#include <json-c/json.h>


#ifndef u64
typedef unsigned long long u64;
#endif
#ifndef u32
typedef unsigned int u32;
#endif
#ifndef u16
typedef unsigned short int u16;
#endif
#ifndef u8
typedef unsigned char u8;
#endif
#ifndef s64
typedef signed long long s64;
#endif
#ifndef s32
typedef signed int s32;
#endif
#ifndef s16
typedef signed short int s16;
#endif
#ifndef s8
typedef signed char s8;
#endif

#ifndef BOOL
#define BOOL int
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef NULL
#define NULL 0
#endif

#define  BYTE_SWAP_16(x)        ( (((x) & 0xFF) << 8) | (((x) & 0xFF00) >> 8) )
#define  BYTE_SWAP_32(x)        ( (((x) & 0xFF) << 24) | (((x) & 0xFF00) << 8) | (((x) & 0xFF0000) >> 8) | (((x) & 0xFF000000) >> 24))

struct os_uptime {
    long long day;
    long long hour;
    long long minute;
    long long second;
};


/**
* 开启一个新的线程
* @param[in]  func 线程回调函数
* @retval  thread_name 线程名称
* @retval  arg 传递给线程的参数，注意此参数如果是指针，指向的不能是局部变量
*/
__EXPORT int os_start_thread(os_thread_function func, char* thread_name, void*arg);
__EXPORT void os_mutex_init(struct os_mutex* mutex);
__EXPORT int os_mutex_lock(struct os_mutex* mutex);
__EXPORT int os_mutex_unlock(struct os_mutex* mutex);
__EXPORT void os_mutex_deinit(struct os_mutex* mutex);
__EXPORT int os_mutex_try_lock(struct os_mutex* mutex);

/**
* 系统当前时间换算的毫秒数 TBD: 测试溢出，返回u64
* @retval  int 毫秒数
*/
__EXPORT unsigned int os_time_now_ms();

/**
* 申请一块堆内存
* @param[in]  len 内存大小
* @retval  void* 内存块
* @retval  NULL 如果分配不成功
*/
__EXPORT void* os_zalloc(int len);


/**
* 睡眠1s
* @retval  void
*/
__EXPORT void os_sleep(int s);

/**
* 睡眠1ms
* @retval  void
*/
__EXPORT void os_msleep(int ms);

/**
* 睡眠1us
* @retval  void
*/
__EXPORT void os_usleep(int us);


/**
* 得到系统时区对应的时间，格式为20200927_024431
* @retval  返回的内存不需要释放
*/
__EXPORT char *os_get_time_str();

/**
* 得到系统时区对应的时间，格式为2020-09-07 02:44:31
* @retval  返回的内存不需要释放
*/
__EXPORT char *os_get_time_str2();

/**
* 得到当前的时间字符串，格式为2020/09/07 02:44:31:123311
* @param[in]  buffer 用来存储时间的内存
* @param[in]  buffer_len 用来存储时间的内存大小
* @retval  返回0
*/
__EXPORT int os_get_time_str3(char* buffer, int buffer_len); // //example:2020/09/07 02:44:31:123311 得到精确的的时间

/**
* 得到当前的时间字符串，格式为（RFC-3339）：2014-03-19T18:42:52.362Z
* @param[in]  buffer 用来存储时间的内存
* @param[in]  buffer_len 用来存储时间的内存大小
* @retval  返回0
*/
__EXPORT int os_get_time_str4(char* buffer, int buffer_len); //RFC-3339


/**
* 设置系统时区，如UTC-8
* @retval  返回0
*/
__EXPORT int os_set_timezone(char *timezone); //设置系统时区

/**
* 得到系统时区，如UTC-8
* @retval  返回的内存需要被释放
*/
__EXPORT char *os_get_timezone(); //得到系统时区，需要被释放

/**
* 得到临时文件的目录
* @retval  返回的内存不需要释放
*/
__EXPORT char* os_temp_dir();

/**
* 得到当前的线程ID
* @retval  返回线程ID
*/
__EXPORT int os_get_thread_id();

/**
* 释放内存
* @param[in]  ptr 传入数据指针
* @retval  返回void
*/
__EXPORT void os_free(void *ptr);

/**
* 得到当前的时间
* @param[in]  tp 用来存储timeval类型的时间
* @param[in]  tzp 用来存储时区
* @retval  返回0
*/
__EXPORT int os_gettimeofday(struct timeval* tp, struct timezone* tzp);

/**
* 得到系统剩余内存MB
* @retval  返回剩余内存大小（MB）。
*/
__EXPORT int os_get_free_memory_mb();

/**
* 得到系统目前所有的物理内存
* @retval  返回物理内存大小（MB）。
*/
__EXPORT int os_get_total_memory_mb();

/**
* 得到系统目前的开机时间
* @param[in]  u 用来存储当前的开机时间
* @retval  返回0。
*/
__EXPORT int os_get_uptime(struct os_uptime *u);

/**
* 得到系统中被占用的内存大小（MB）。
* @retval  返回被占用的内存大小（MB）。
*/
__EXPORT int os_get_program_memory_taken_mb();

/**
* 得到计算机名称
* @param[in]  hostname 用来存储的主机名
* @param[in]  hostname_len 用来存储的主机名长度
* @retval  成功返回0，hostname存储主机名。
*/
__EXPORT int os_gethostname(char *hostname, int hostname_len);

/**
* 得到操作系统版本
* @retval  写死"Windows"
*/
__EXPORT char* os_get_version();

/**
* 得到TCP表，效果类似 netstat -a 
* @retval  返回一个csv格式的字符串，需要释放，例子：
* 
* LOCAL_ADDR,LOCAL_PORT,REMOTE_ADDR,REMOTE_PORT,STATE
* 127.0.0.1,2000,127.0.0.1,3000,LISTEN
* 127.0.0.2,2000,127.0.0.2,4000,LISTEN
*/
__EXPORT char* os_get_tcp_table();

/**
* 得到没有被使用的tcp端口
* @param[in]  port_start 开始的端口
* @param[in]  port_end 结束的端口
* @retval  成功返回第一个得到的可用的端口，失败返回-1
*/
__EXPORT int os_get_free_tcp_port(int port_start, int port_end);

/**
* 服务的主函数，windows下首先需要通过sc.exe来注册到系统服务。目前暂时Linux没有实现。
* @param[in]  service_name 服务的名称，如"suanpan-link"
* @param[in]  exe_name 服务启动的exe名称
* @param[in]  service_func 服务启动的回调函数
* @retval  实际的数据，如果没有则返回NULL
*/
__EXPORT void os_service_start(char* service_name, char* exe_name, os_service_func f);

#endif
