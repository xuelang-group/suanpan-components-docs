#ifndef __SP_RPC_H__
#define __SP_RPC_H__

#include "sdk_os.h"
__EXPORT void sp_rpc_start_dll(char *oss_package_path, char *function_name);


#endif