#ifndef __HTTP_SERVER__
#define __HTTP_SERVER__


#include "sdk_os.h"
#include "json_easy.h"

enum SDK_HTTP_METHOD {
    SDK_HTTP_METHOD_EMPTY = 0,
    SDK_HTTP_METHOD_GET = 100,
    SDK_HTTP_METHOD_POST = 101,
};


struct http_server_cb_param {
    void *handle;
    char *url; 
    json_object *post_obj; 
    json_object *get_obj; 
    json_object *file_obj; 
    json_object *cookie_jobj;
    void *user;
};

typedef void * HttpServerHandle;

#define HTTP_HANDLED 1
#define HTTP_NOT_HANDLED 0

/** 
* 客户端有数据发送的时候，产生的回调
* @param[in]   handle 客户端的句柄.
* @param[in]   url 客户端get或者post的url. 
* @param[in]   post_jobj 以json给出的post内容.
* @param[in]   query_jobj 以json给出的query内容.
* @param[in]   file_jobj 以json给出的file内容
* @param[in]   user 用户自定义指针
* @return HTTP_HANDLED http请求被正确处理
* @return HTTP_NOT_HANDLED http请求没有被正确处理，交由CGI_Callback来处理。如果HTTP_Server_Callback里面没有代码，可以返回HTTP_NOT_HANDLED
*/
typedef int (*HTTP_Server_Callback)(struct http_server_cb_param *param);


/** 
* 客户端有数据发送的时候，产生的回调
* @param[in]   handle 客户端的句柄.
* @param[in]   url 客户端get或者post的url. 
* @param[in]   post_jobj 以json给出的post内容.
* @param[in]   query_jobj 以json给出的query内容.
* @param[in]   file_jobj 以json给出的file内容
* @param[in]   user 用户自定义指针
*/
typedef void (*HTTP_Server_CGI_Callback)(struct http_server_cb_param *param);

/** 
* 向客户端返回响应
* @param[in]   handle 客户端的句柄.
* @param[in]   response 响应代码，比如200. 
* @param[in]   content_type HTTP content_type.
* @param[in]   result 内容.
* @param[in]   result_len 内容长度.
*/
__EXPORT void SDK_HTTP_Server_Send_Response(void *handle, int response,
                    char *content_type, char* result, int result_len);

/** 
* 向客户端返回内容，一般是SDK_HTTP_Server_Send_Response需要返回更多内容时调用
* 一般发送音视频流数据才用到。
* @param[in]   handle 客户端的句柄.
* @param[in]   result 数据内容. 
* @param[in]   result_length 数据长度.
*/
__EXPORT void SDK_HTTP_Server_Send_Response_Body(void *handle, char* result, int result_length);


/** 
* 向客户端返回一个文件
* @param[in]   handle 客户端的句柄.
* @param[in]   filename 文件名. 
* @param[in]   buffer 文件内容.
* @param[in]   buffer_length 文件长度.
*/
__EXPORT void SDK_HTTP_Server_Send_File_Response(void *handle, char *filename, char* buffer, int buffer_length);
/** 
* 注册对应目录的回调函数
* @param[in]   handle HTTP服务器的句柄
* @param[in]   method 方法，可以是SDK_HTTP_GET或者SDK_HTTP_POST. 
* @param[in]   url 域名目录.
* @param[in]   callback 回调函数.
*/
__EXPORT int SDK_HTTP_Server_Register_CGI(HttpServerHandle handle, int method, char *url, HTTP_Server_CGI_Callback callback);

/**
 * 设置服务器的cookie，目前只能设置一个
 * @param[in]   handle 客户端回调的句柄
 * @param[in]   key 键
 * @param[in]   val 值
 * @param[in]   cookie超时时间，单位为秒
*/
__EXPORT int SDK_HTTP_Server_Send_Cookie(void* handle, char *key, char*val, int timeout);

/**
 * 设置服务器的webroot位置
 * @param[in]   handle 客户端回调的句柄
 * @param[in]   webroot webroot位置
*/
__EXPORT int SDK_HTTP_Server_Set_Webroot(void* handle, char *webroot);

/** 
* 开启一个HTTP服务器
* @param[in]   port 端口
* @param[in]   callback 数据回调. 所有GET和POST都会回调到这里，如果需要精细回调，可以使用SDK_HTTP_Server_Register_CGI
* @param[in]   user 用户自定义数据. 
*/
__EXPORT HttpServerHandle SDK_HTTP_Server_Start(int port, HTTP_Server_Callback callback, void *user);

/** 
* 关闭一个HTTP服务器
*/
__EXPORT int SDK_HTTP_Server_Stop(HttpServerHandle server);

#endif
