#ifndef __JPEG_ENCODE__
#define __JPEG_ENCODE__

#include "sdk_os.h"
__EXPORT int BMP_To_JPEG(char *buffer, char** out_buffer,
                int width, int height, int quality);

#endif