#ifndef __SDK_VERSION__
#define __SDK_VERSION__
#define SDK_VERSION "1.2.24"
#endif
