#ifndef __XL_LUA_H__
#define __XL_LUA_H__

#include "sdk_os.h"

__EXPORT void *xl_lua_new();
//���ص��ڴ���Ҫ�ͷ�
__EXPORT char* xl_lua_call_script(void *xl_lua_ctx, char *lua_function_code, char *function_name, char *para);
//���ص��ڴ���Ҫ�ͷ�
__EXPORT char* xl_lua_call_script_args(void* xl_lua_ctx, char* lua_function_code, char* function_name, int para_num, char* para[]);
__EXPORT int xl_lua_free(void *xl_lua_ctx);

#endif