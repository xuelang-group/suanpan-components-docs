## suanpan-c-sdk v1.2.24 (20220117)
1.修复udp在windows下发送失败
2.增加redis client接口，支持二进制数据
3.csv使用浅拷贝方法提升删除性能
4.增加跨平台串口API
5.增加map接口
6.增加os_service_start API
7.内置luajit引擎
8.更新一些头文件文档
9.修复自带的example


## suanpan-c-sdk v1.2.23 (20210930)
1.修复bmp符号在windows下找不到的问题。
2.发布jetson和树莓派上面的编译版本
3.修复CSV的EOF变量的bu。
4.修复windows下一些头文件和库文件的缺失
5.修复minio在windows下并发保存文件的问题。
6.修复websocket释放内存产生挂掉的问题。

## suanpan-c-sdk v1.2.22 (20210916)

1.增加算盘logkit API，兼容socketio新的版本。
2.增加Kafka API
3.修复minio路径不对的问题。

## suanpan-c-sdk v1.2.21 (20210819)

修复问题
1.修改bool/true/false为大写，防止冲突
2.TRAP接口增加，并且增加回调
3.OSS修复内存不断增长的问题
4.redis/minio接口支持单机版Windows。增加端口申请，端口注册逻辑。
5.修复minio路径错误的问题
6.修复config接口内存泄露的问题
7.hiredis接口API更新到v1.0.0

## suanpan-c-sdk v1.2.20 (20210610)
修复问题
1.CSV内存覆盖
2.JSON复合格式时路径错误
3.BMP头部为负值的错误
4.HTTP服务器修复分段JSON Post请求
5.MD5函数内部屏蔽

## suanpan-c-sdk v1.2.19 (20210420)
功能增强
1.npy转换接口支持图片上下翻转
2.http server支持指定webroot来'换肤'

## suanpan-c-sdk v1.2.18 (20210326)
修复问题
1.loglevel为verbose下crash
2.websocket server内存错误的问题
3.windows下随机数不随机的问题


## suanpan-c-sdk v1.2.17 (20210308)

windows 问题修复

1.mqtt支持多线程，单线程会重入问题，修复socket资源泄露 

2.websocket卡住奔溃的问题

3.修复timer资源泄露

4.增加pdb调试信息



## suanpan-c-sdk v1.2.16 (20210303)

windows 问题修复
1.timer
2.uuid
3.http server
4.websocket
5.增加mingw编译支持 

## suanpan-c-sdk v1.2.15 (20210204)

windows问题修复

1.修复timer未加锁导致混乱

2.修复csv在windows下\r\n处理的问题

3.修复http server对于大文件post处理不当的问题



## suanpan-c-sdk v1.2.14 (20210129)

增加windows支持

1.新的http服务器用于windows环境

2.新的timer支持

3.增加OS API

4.跨平台的logger



## suanpan-c-sdk v1.2.13 (20210115)

增加预编译的依赖库，兼容更多平台

## suanpan-c-sdk v1.2.12 (20201216)

### HTTP Client

1.增加文件下载的API

### JPEG

1.增加JPEG转bmp的功能

## suanpan-c-sdk v1.2.11 (20201208)

### HTTP Server

1.修改回调API，如果没有被处理并且文件不存在增加404的功能
2.增加Cookie功能

### Json

1.Json对象转字符串的时候默认压缩体积

## suanpan-c-sdk v1.2.10 (20201207)

### HTTP Client

增加新的接口`SDK_HTTP_Client_Post2`，修复内存泄漏问题

### FIFO

增加一个打印FIFO信息的API`void sdk_fifo_info(SDK_FiFo fifo);`

## suanpan-c-sdk v1.2.9 (20201203)

### ICONV

新加的ICOV bug解决困难，转而使用外部的ICONV库，防止buildroot环境gcc自带的的iconv UTF8转换失败

### BMP

编码转换图片倒置

## suanpan-c-sdk v1.2.8 (20201123)

### TCP Client

修复连不上时120s超时太长的问题，降低到7秒超时

### Logger

修复打印超过1000字节挂掉的问题

### String

添加GB2312-UTF8字符编码模块，规避某些平台iconv失败的问题。

## suanpan-c-sdk v1.2.7 (20201119)

### HTTP Server

增加对目录文件的支持，比如 127.0.0.1/doc/ , 默认转到127.0.0.1/doc/index.html

## suanpan-c-sdk v1.2.6 (20201118)

### 其他

增加一些库，由SDK来编译而不是外部提供

## suanpan-c-sdk v1.2.5 (20201112)

### 其他

删除一些log，在ubuntu 18.04 docker中编译干净的sdk

## suanpan-c-sdk v1.2.4 (20201104)

### mqtt
* 增加API回调功能，提高发送性能


## suanpan-c-sdk v1.2.3 (20201023)

### timer
* API Callback添加频率字段, 方便用户使用

### udp socket

* 添加此功能

### suanpan

* 修复内存覆盖问题
* 增加一个基础镜像，方便用户二次release

### http server

* 修改index.html的位置到webroot下，兼容原有方式

  

## suanpan-c-sdk v1.2.1 (20201003)

### utility

* 增加itoa函数

### websocket server

* 修复存在的bug

## suanpan-c-sdk v1.1.20 (2020922)

### example

修复示例代码

### tcp socket

- 添加此功能，并且修复bug

### config file

* 增加新的API，可以从内存中读写buffer结构体，而不是必须从文件操作
* 增加新的API，可以以数组下标的方式得到Section, Item, Value的实例，而不是需要一个个遍历，方便了代码的编写。

### logger

* 删除了多余的console彩色打印字符，在算盘上会被判定为乱码



## suanpan-c-sdk v1.1.19 (2020916)

### fifo

* 修复了浅拷贝，死锁等问题

### logger

* 增加日志到内存区域，并且内存区域大小可以控制，可以rotate，方便用户导出日志或者在前端查看日志

### fifo

* 增加了fifo的操作函数并且修复一些问题

### http server

* 修复重复响应的问题
* 支持更多的mime type

### time zone

* 支持设置系统时区和得到系统时区

## suanpan-c-sdk v1.1.18 (2020910)

### socketio

* 修复socketio连接过快，导致用户后来注册的回调函数没有被调用，通过sleep的方式等待用户注册好回调函数。
* 修复ping机制
* 修复socketio连接状态机

### timer

* 修复若干内存泄漏问题

### string

* 修复iconv转换失败的问题

### csv

* 修复内存泄漏问题

### http server

* 增加cgi注册函数，方便用户调用
* 修复内存泄漏问题

### websocket server

* 修复状态机内存泄露问题
* 修复deinit的时候的报错
* 修改API，更易于使用

### suanpan

* 修复消息队列内存泄漏问题

## suanpan-c-sdk v1.1.17 (2020907)

### http server

* 增加post数据体大小

### csv

* 增加csv API
* 增加拷贝函数
* 修复删除的问题

### suanpan

* 修复mq回调因为没有回调函数注册导致的crash问题
* 修改mq本地调试工具，增加websocket信息显示

### utility

* 增加switch接口，在c里面可以使用string的switch
* 增加字符编码转换接口

## suanpan-c-sdk v1.1.15 (2020826)

### timer

* 增加timer接口，两种不同的方式实现，推荐使用timer2

### encryption lock

* 增加深思数盾加密狗的API

## suanpan-c-sdk v1.1.14 (2020804)

### suanpan

* 修复内存溢出

### socketio client

* 支持Qos队列
* 增加多线程测试
* 增加数据缓存机制
* 增加服务器回调机制
* 增加log file机制
* 支持多实例
* 修复连接问题
* 修复多数据包发送会丢包的问题
* 增加sp rocket的示例
* 修复汉字的编码
* 增加C#接口API文档
* 修复引号带来的问题
* 修复C# 垃圾回收带来的问题
* 增加socketio测试服务器
* 增加C#的易于使用的异步API，C#多参数支持
* 修复大量内存泄漏
* 增加重连机制

### websocket server

* 修复rx大数据包产生的内存错误

## suanpan-c-sdk v1.1.13 (2020721)

### http client

* 将请求修改为json交互类型

### http server

* 支持application/json

### config

* 修复内存泄漏问题

### websocket server

* 修复死锁问题
* 修复发送和接收大数据包错误的问题

### socketio client

* 增加事件回调
* 状态机机制

### suanpan

* 增加rpc接口
* 增加suanpan mq调试工具
* 修复redis队列出错
* 删除多余的打印

## suanpan-c-sdk v1.1.7 (2020710)

### suanpan

* 增加OSS接口

* 增加local storage接口

* 增加minio接口

* 增加fake storage接口

* 增加fake mq接口

* 修复env接口

* 增加fake env接口

* 增加多mq处理流程

  

### socketio client

* 增加一个初步的协议栈代码和demo

### os

* 增加windows支持



## suanpan-c-sdk v1.1.6 (2020707)

### doc

* 增加config file， file， json easy，mq，logger的文档注释

### suanpan

* 增加minio和storageAPI
* 增加http server的例子

### sdk

* 删除大量用户代码， 移动到suanpan-c仓库



## suanpan-c-sdk v1.1.2 (2020701)

### suanpan

* 增加minio的一些基本功能
* 增加oss的基本功能



## suanpan-c-sdk v1.1.1 (2020628)

### build

* 增加extern和archive机制

## suanpan-c-sdk v1.0.3 (2020624)

### suanpan

* 将redis接口改为算盘接口
* 增加虚拟环境
* 增加oss

#### websocket client

* 功能增加

#### websocket server

* 支持多个客户端

#### socketio client

* 增加基础代码，可以连上服务器

#### http server

* 支持文件上传

#### media

* yuv420问题修复

## 
