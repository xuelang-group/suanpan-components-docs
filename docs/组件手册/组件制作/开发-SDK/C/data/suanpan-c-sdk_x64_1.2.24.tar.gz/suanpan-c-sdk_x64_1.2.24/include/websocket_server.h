#ifndef __WEBSOCKER_SERVER_H__
#define __WEBSOCKER_SERVER_H__


#include "sdk_os.h"

#ifndef WS_CB_TEXT
enum ws_callback_type {
    WS_CB_CONTINUE = 0,
    WS_CB_TEXT,
    WS_CB_BINARY,
    WS_CB_CLOSE,
    WS_CB_PING,
    WS_CB_PONG,
};
#endif

typedef void* WS_Server_Handle;

/** 
* 客户端有数据上传时
* @param[in]   handle 客户端的句柄. 
* @param[in]   type 回调类型. 
* @param[in]   data 回调数据. 
* @param[in]   length 回调长度. 
* @param[in]   user 用户自定义数据. 
*/
typedef void (*WS_Server_Callback)(void *handle, enum ws_callback_type type, 
                        char *data, int length, void*user);

/** 
* 客户端连接到本服务器时
* @param[in]   handle 客户端的句柄. 
*/
typedef void (*WS_Server_On_Open)(void *handle);
/** 
* 客户端从本服务器断开时
* @param[in]   handle 客户端的句柄. 
*/
typedef void (*WS_Server_On_Close)(void *handle);


/** 
* @brief
*    服务器回调参数
*/
struct ws_server_cb_param {
    /*! @brief   服务器接收到数据的时候的回调 */
    WS_Server_Callback callback;
    /*! @brief   服务器有客户端连接时候的回调 */
    WS_Server_On_Open onopen;
    /*! @brief   服务器有客户端下线时候的回调 */
    WS_Server_On_Close onclose;
    /*! @brief   用户自定义的数据 */
    void *user;
    //void *handle;
};

/** 
* 开启一个websocket服务器
* @param[in]   port 服务器监听的端口. 
* @param[in]   param 回调参数. 
* @param[in]   protocol_name 多路复用的ws协议名称，默认是data_trans. 
* @retval  非空指针WS_Server_Handle 成功 
* @retval  NULL  错误
*/
__EXPORT WS_Server_Handle WS_Server_Start(int port, struct ws_server_cb_param *param);
__EXPORT WS_Server_Handle WS_Server_Start2(int port, char *protocol_name, struct ws_server_cb_param *param);

/** 
* 关闭一个websocket服务器
* @param[in]   handle WS服务器的句柄. 
* @retval  0  成功 
* @retval  -1  错误
*/
__EXPORT int WS_Server_Stop(WS_Server_Handle handle);
/** 
* 向websocket发送二进制数据
* @param[in]   handle 客户端的句柄. 需要在onopen后得到
* @param[in]   data 数据. 
* @param[in]   length 数据长度. 
* @retval  0  成功 
* @retval  -1  错误
*/
__EXPORT int WS_Server_Send_Binary(void *handle, char *data, int length);
/** 
* 向websocket发送字符串数据
* @param[in]   handle 客户端的句柄. 需要在onopen后得到
* @param[in]   data 数据. 
* @retval  0  成功 
* @retval  -1  错误
*/
__EXPORT int WS_Server_Send_String(void *handle, char *data);
/** 
* 向websocket发送二进制数据，此接口不会阻塞直到发送成功
* @param[in]   handle 客户端的句柄. 需要在onopen后得到
* @param[in]   data 数据. 
* @param[in]   length 长度. 
* @retval  0  成功 
* @retval  -1  错误
*/
__EXPORT int WS_Server_Send_Binary_Nonblock(void *handle, char *data, int length);
/** 
* 向websocket发送字符串数据，此接口不会阻塞直到发送成功
* @param[in]   handle 客户端的句柄. 需要在onopen后得到
* @param[in]   data 数据. 
* @retval  0  成功 
* @retval  -1  错误
*/
__EXPORT int WS_Server_Send_String_Nonblock(void *handle, char *data);



#endif
