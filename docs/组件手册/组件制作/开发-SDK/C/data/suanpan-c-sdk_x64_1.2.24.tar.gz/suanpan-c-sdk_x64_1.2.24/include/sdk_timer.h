#ifndef __SDK_TIMER_H__
#define __SDK_TIMER_H__

//本定时器回调来自线程，不会死锁，精度是10ms

typedef void* Timer_Handle;
typedef void (*Timer_Callback)(Timer_Handle handle, char *name, void *arg); 

Timer_Handle sdk_timer_init();
int sdk_timer_add_handler(Timer_Handle hdl, char *name, int interval, 
                            Timer_Callback cb, void *arg);
int sdk_timer_del_handler(Timer_Handle hdl, Timer_Callback cb);
int sdk_timer_stop(Timer_Handle hdl);


#endif