#ifndef __WEBSOCKER_CLIENT_H__
#define __WEBSOCKER_CLIENT_H__

#include "sdk_utility.h"

/**
 * Websocket implementation: WebSocket text frames use a terminator, while binary frames use a length prefix.
*/

#ifndef WS_CB_TEXT
enum ws_callback_type {
    WS_CB_CONTINUE = 0,
    WS_CB_TEXT,
    WS_CB_BINARY,
    WS_CB_CLOSE,
    WS_CB_PING,
    WS_CB_PONG,
};
#endif

typedef void (*WS_Client_Callback)(void *handle, BOOL binary, char *data, int length, void*user);
typedef void (*WS_Client_On_Open)(void *handle, void*user);
typedef void (*WS_Client_On_Close)(void *handle, void*user);
typedef void (*WS_Client_Add_Header)(void *handle, char *header_json);
typedef void (*WS_Client_On_Loop)(void *handle);
typedef void *WS_Handle;

struct ws_client_cb_param {

    WS_Client_Callback callback;
    WS_Client_On_Open onopen;
    WS_Client_On_Close onclose;
    WS_Client_Add_Header addheader;
    WS_Client_On_Loop onloop;

    void *user;

};

#include "sdk_os.h"

__EXPORT WS_Handle WS_Client_Start(char *host, int port, char *url, char *header_json,
        struct ws_client_cb_param *callback, void* user_data);
__EXPORT WS_Handle WS_Client_Start2(char *host, int port, char *url,  char *protocol_name, char *header_json,
        struct ws_client_cb_param* callback, void* user_data);
__EXPORT int WS_Client_Send_Binary(WS_Handle handle, char *data, int length);
__EXPORT int WS_Client_Send_String(WS_Handle handle, char *data);
__EXPORT int WS_Client_Stop(WS_Handle handle);
__EXPORT int WS_Client_Connected(void *handle);


#endif
