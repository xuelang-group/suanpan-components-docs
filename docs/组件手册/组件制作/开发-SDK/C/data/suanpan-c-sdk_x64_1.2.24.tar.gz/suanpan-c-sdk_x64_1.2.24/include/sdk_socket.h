#ifndef __SDK_SOCKET_H__
#define __SDK_SOCKET_H__

#include "sdk_utility.h"

#define TCP_READ_ERR -1
#define TCP_READ_CLOSED -2
#define TCP_READ_TIMEOUT -3

#include "sdk_os.h"

__EXPORT int TCP_Socket_Create_Server(int portno);
__EXPORT int TCP_Socket_Accept(int server_fd, int timeout_ms);

__EXPORT int TCP_Socket_Create_Client(char *addr, int port, int timeout_ms);
__EXPORT int TCP_Socket_Read(int socket_fd, unsigned char* buffer, int len, int *ret_len);
__EXPORT int TCP_Socket_Write(int socket_fd, unsigned char* buffer, int len);
__EXPORT int TCP_Socket_Close(int fd);
__EXPORT int TCP_Socket_Flush_Read(int socket_fd);

__EXPORT int TCP_Socket_KeepAlive(int s, int ktime, int kinterval, int kprobes);
__EXPORT int TCP_Socket_Peek(int socket_fd, u8 *buffer);


__EXPORT int UDP_Socket_Create_Client();
__EXPORT int UDP_Socket_Create_Server(int port);
__EXPORT int UDP_Socket_Receive(int Socket, u8* recv_buf, int recv_len, struct sockaddr_in *peeraddr);
__EXPORT int UDP_Socket_Send_Bin(int Socket, char* ip, int port, char* data, int data_len);
__EXPORT int UDP_Socket_Send(int Socket, char* ip, int port, char* data);
__EXPORT int UDP_Socket_Close(int Socket);


#endif