/**         
 * @file sp_mq.h                 
 * @brief 算盘组件通讯接口。组件一般有多个输入和多个输出。通过sp_mq_register_callback注册回调来监听输入消息
 * 通过直接调用sp_mq_send来将消息输出。因为有多个端口，所以输入输出的时候需要指定端口。
 */
#ifndef __SUANPAN_MQ_H__
#define __SUANPAN_MQ_H__

#include "sdk_utility.h"

typedef void *Sp_mq;

#include "sdk_os.h"

/** 
* 消息队列回调函数. 
* @param[in]   mq 消息队列句柄. 
* @param[in]   input_port_name 从流计算输入的端口. 
* @param[in]   input_data 从流计算输入的数据. 
* @param[in]   input_uuid 从流计算输入的uuid. 
* @retval  0  成功 
* @retval  -1   错误  
*/
typedef void(*sp_mq_callback)(Sp_mq mq,  char *input_port_name,
                    char *input_data, char *input_uuid, void *user);


/** 
* 注册一个消息队列回调. 
* @param[in]   mq 消息队列句柄. 
* @param[in]   cb 消息队列回调函数. 
* @param[in]   user 用户参数. 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int sp_mq_register_callback(Sp_mq mq, sp_mq_callback cb, void *user);


/** 
* 向消息队列对应端口发送数据. 
* @param[in]   mq 消息队列句柄. 
* @param[in]   output_port_name 输出端口. 
* @param[in]   output_data 输出数据. 
* @param[in]   uuid 输出的uuid，如果在回调里面，需要提供，如果主动发送，不需要提供. 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int sp_mq_send(Sp_mq mq,  char *output_port_name, char *output_data,char *uuid);

/**
* 向算盘发送错误消息.
* @param[in]   mq 消息队列句柄.
* @param[out]   message 输出的错误信息.
* @retval  0  成功
* @retval  -1   错误
*/
__EXPORT int sp_send_error(Sp_mq mq, char* message);

/** 
* 初始化一个消息队列实例
* @retval  Sp_mq  得到句柄
* @retval  NULL   错误  
*/
__EXPORT Sp_mq sp_mq_init();
/** 
* 删除一个消息队列实例
* @param[in]   mq 句柄. 
* @retval  0  成功
* @retval  NULL  错误  
*/
__EXPORT int sp_mq_deinit(Sp_mq mq);



#endif