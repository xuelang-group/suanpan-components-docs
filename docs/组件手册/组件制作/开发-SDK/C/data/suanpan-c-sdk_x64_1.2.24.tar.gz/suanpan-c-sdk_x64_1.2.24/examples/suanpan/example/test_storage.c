
#include "sdk_utility.h" //包含LOGD,os_sleep等函数，用户可以不使用
#include "sp_mq.h"
#include "sp_storage.h"
#include "sp_env.h"
#include "bmp_to_npy.h"
#include "bmp_encode.h"

#define TAG "TEST_STORAGE"


void mq_callback_storage(Sp_mq mq, 
				char *input_port_name, 
				char *input_data, 
            	char *uuid,
				void *user)
{
	LOGD(TAG, "Received %s from %s", input_data, input_port_name);

	SP_Storage storage = (SP_Storage)user;

	char *out_buffer;
	int out_size;
	int ret = sp_tmp_file_load(storage, input_data, "data.csv", &out_buffer, &out_size);
	if (ret == 0) {
		int i = 0;
		for (i = 0; i < out_size; i++) {
			printf("%c", out_buffer[i]);
		}
		fflush(stdout);
		int delete_result = sp_tmp_file_delete(storage, input_data, "data.csv");
		if (delete_result == 0) {
			LOGD(TAG, "Delete success");
		}
	} else {
		LOGE(TAG, "Load file fail ret=%d", ret);
	}

}


void sp_storage_test()
{
	SP_Storage hdl = sp_storage_init(); //初始化本地存储

	Sp_mq mq =  sp_mq_init();  //初始化一个mq
	sp_mq_register_callback(mq, mq_callback_storage, hdl); //注册mq回调

	while (1) {
		char *buffer = "id,name,age\r\n1,Alice,18\r\n2,Bob,19\r\n"; //需要保存的文件内容，这里是一个简单的csv字符串

		char *path = sp_tmp_file_save(hdl,  //将文件保存到本地
					NULL, //message_id
					"out1", //需要发送的端口 out1
					"data.csv", //保存的文件名
					buffer,
					strlen(buffer));
		LOGD(TAG, "Send path=%s", path);
		sp_mq_send(mq, "out1", path, NULL); //将本地的文件路径通过mq端口out1发送到下一个节点

		free(path);
		os_sleep(10);
	}

}


int test_storage()
{
	sp_storage_test();
}
