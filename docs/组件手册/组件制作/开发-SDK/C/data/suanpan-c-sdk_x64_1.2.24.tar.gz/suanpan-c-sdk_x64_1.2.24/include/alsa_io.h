#ifndef __ALSA_IO_H_
#define __ALSA_IO_H_


//Only support S16_LE 16K I/O data
typedef void * ALSA_Handle;
ALSA_Handle alsa_init(char *input_device, char *output_device); //todo add device name
int alsa_deinit(ALSA_Handle handle);
int alsa_write(ALSA_Handle handle, unsigned char *buffer, int length);
int alsa_read(ALSA_Handle handle, unsigned char **buffer, int *length);
int alsa_flush(ALSA_Handle handle);

#endif
