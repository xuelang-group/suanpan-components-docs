#ifndef _SDK_MD5_H_
#define _SDK_MD5_H_

#include "sdk_os.h"

__EXPORT void SDK_MD5String (char *string,unsigned char digest[16]);
__EXPORT int SDK_MD5File (char *filename,unsigned char digest[16]);

#endif

