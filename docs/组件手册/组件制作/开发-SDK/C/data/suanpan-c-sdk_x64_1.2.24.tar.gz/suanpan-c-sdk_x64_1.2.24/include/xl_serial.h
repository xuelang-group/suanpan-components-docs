/*
 * c-periphery
 * https://github.com/vsergeev/c-periphery
 * License: MIT
 */

#ifndef _PERIPHERY_SERIAL_H
#define _PERIPHERY_SERIAL_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

enum serial_error_code {
    SERIAL_ERROR_ARG            = -1, /* Invalid arguments */
    SERIAL_ERROR_OPEN           = -2, /* Opening serial port */
    SERIAL_ERROR_QUERY          = -3, /* Querying serial port attributes */
    SERIAL_ERROR_CONFIGURE      = -4, /* Configuring serial port attributes */
    SERIAL_ERROR_IO             = -5, /* Reading/writing serial port */
    SERIAL_ERROR_CLOSE          = -6, /* Closing serial port */
};

#ifndef _WIN32
typedef enum serial_parity {
    PARITY_NONE,
    PARITY_ODD,
    PARITY_EVEN,
} serial_parity_t;
#else
typedef int serial_parity_t;
#endif

typedef struct serial_handle serial_t;

/** 
* 获取当前的串口列表
* @param[out]  name_list 获取串口列表名
* @param[in]   max_id 获取串口列表名的最大数量 
* @return 当前串口数量
*/
int xl_serial_get_list(char *name_list[],int max_id);

/** 
* 判断串口是否存在
* @param[in]   name 输入需要判断的串口名 
* @return  0: 不存在；1：存在
*/
int xl_is_serial_exist(const char* name);    

/** 
* 申请一个串口句柄
* @return  serial_t 申请成功的句柄地址
*/
serial_t *xl_serial_new(void);

/** 
* 打开串口
* @param[in]   serial 操作的串口句柄 
* @param[in]   path 需要打开串口名（由xl_serial_get_list获取）
* @param[in]   baudrate 配置串口的波特率（可配置参数为9600，19200，38400，57600，115200）
* @return  0: 成功；其他（查找对应错误码）
*/
int xl_serial_open(serial_t *serial, const char *path, uint32_t baudrate);

/** 
* 打开串口
* @param[in]   serial 操作的串口句柄 
* @param[in]   path 需要打开串口名（由xl_serial_get_list获取）
* @param[in]   baudrate 配置串口的波特率（可配置参数为9600，19200，38400，57600，115200）
* @param[in]   databits 配置串口的数据位（可配置参数为5，6，7，8）
* @param[in]   parity 配置串口的奇偶校验位（可配置参数为0：无校验，1：奇校验，2：偶校验）
* @param[in]   stopbits 配置串口的停止位（可配置参数为1，2）
* @param[in]   xonxoff 开关串口的异步通信（可配置参数为1：开，0：关）
* @param[in]   rtscts 开关串口的流控（可配置参数为1：开，0：关）
* @return  0: 成功；其他（查找对应错误码）
*/
int xl_serial_open_advanced(serial_t *serial, const char *path,
                         uint32_t baudrate, unsigned int databits,
                         serial_parity_t parity, unsigned int stopbits,
                         bool xonxoff, bool rtscts);

/** 
* 读取串口数据
* @param[in]   serial 操作的串口句柄 
* @param[out]  buf 接收数据的缓存地址 
* @param[in]   len 接收数据的最大长度
* @param[in]   timeout_ms 等待超时时间
* @return  读取数据的实际长度
*/
int xl_serial_read(serial_t *serial, uint8_t *buf, size_t len, int timeout_ms);

/** 
* 写入串口数据
* @param[in]   serial 操作的串口句柄 
* @param[out]  buf 发送数据的缓存地址 
* @param[in]   len 发送数据的最大长度
* @return  0: 成功；其他（查找对应错误码）
*/
int xl_serial_write(serial_t *serial, const uint8_t *buf, size_t len);

/** 
* 清空串口缓存数据
* @param[in]   serial 操作的串口句柄 
* @return  0: 成功；其他（查找对应错误码）
*/
int xl_serial_flush(serial_t *serial);

/** 
* 关闭串口
* @param[in]   serial 操作的串口句柄 
* @return  0: 成功；其他（查找对应错误码）
*/
int xl_serial_close(serial_t *serial);

/** 
* 释放一个串口句柄
*/
void xl_serial_free(serial_t *serial);

/** 
* 动态获取串口参数
* @param[in]   serial 操作的串口句柄 
* @param[out]  对应串口参数状态
* @return  0: 成功；其他（查找对应错误码）
*/
int xl_serial_get_baudrate(serial_t *serial, uint32_t *baudrate);
int xl_serial_get_databits(serial_t *serial, unsigned int *databits);
int xl_serial_get_parity(serial_t *serial, serial_parity_t *parity);
int xl_serial_get_stopbits(serial_t *serial, unsigned int *stopbits);
int xl_serial_get_xonxoff(serial_t *serial, bool *xonxoff);
int xl_serial_get_rtscts(serial_t *serial, bool *rtscts);

/** 
* 动态配置串口参数
* @param[in]   serial 操作的串口句柄 
* @param[in]   对应串口参数配置
* @return  0: 成功；其他（查找对应错误码）
*/
int xl_serial_set_baudrate(serial_t *serial, uint32_t baudrate);
int xl_serial_set_databits(serial_t *serial, unsigned int databits);
int xl_serial_set_parity(serial_t *serial, serial_parity_t parity);
int xl_serial_set_stopbits(serial_t *serial, unsigned int stopbits);
int xl_serial_set_xonxoff(serial_t *serial, bool enabled);
int xl_serial_set_rtscts(serial_t *serial, bool enabled);

/** 
* 获取串口配置，以字符串形式输出
* @param[in]   serial 操作的串口句柄 
* @param[out]  str 获取串口信息的缓存地址 
* @param[in]   len 获取串口信息的最大长度
* @return  0: 成功；其他（查找对应错误码）
*/
int xl_serial_get_info(serial_t *serial, char *str, size_t len);

#ifdef __cplusplus
}
#endif

#endif

