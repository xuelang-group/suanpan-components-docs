#!/bin/sh

export LD_LIBRARY_PATH=../../../sdk/suanpan-c-sdk/library/:../../../library 

