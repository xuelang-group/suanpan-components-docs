#ifndef __SYSTEM_INFO__H__
#define __SYSTEM_INFO__H__

#include "sdk_os.h"
__EXPORT int get_ip_addr(char *ifname, char *result);
__EXPORT int get_system_info(unsigned long *memory_total, unsigned long *memory_free, unsigned long *uptime);

#endif