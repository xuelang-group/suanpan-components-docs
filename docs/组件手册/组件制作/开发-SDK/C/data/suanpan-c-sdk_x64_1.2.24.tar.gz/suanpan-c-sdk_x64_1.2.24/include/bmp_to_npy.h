#ifndef __BMP_TO_NPY__
#define __BMP_TO_NPY__

#include "sdk_os.h"

__EXPORT int bmp_to_npy(char *buffer, int bmp_header_offset, int width, int height,
    char **out_buffer, int *out_len);

//reverse: 转置
__EXPORT int bmp_to_npy2(char *buffer, char **out_buffer, int *out_len, int reverse);

#endif