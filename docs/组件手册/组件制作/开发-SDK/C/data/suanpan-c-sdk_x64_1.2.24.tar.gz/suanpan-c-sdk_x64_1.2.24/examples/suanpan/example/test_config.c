
#include "sdk_utility.h" //包含LOGD,os_sleep等函数，用户可以不使用
#include "sp_mq.h"
#include "sp_storage.h"
#include "sp_env.h"

#define TAG "TEST_CONFIG"

void mq_callback_config(Sp_mq mq, 
				char *input_port_name, 
				char *input_data, 
            	char *uuid,
				void *user)
{
	LOGD(TAG, "Received %s from %s", input_data, input_port_name);

	SP_Storage storage = (SP_Storage)user;

	char *out_buffer;
	int out_size;

	//这里读取my8.txt的配置内容
	int ret = sp_config_load(storage, NULL, "my8.txt", &out_buffer, &out_size);
	if (ret == 0) {
		//读取成功
		LOGD(TAG, "Load back from storage=%s", out_buffer);
		sp_mq_send(mq, "out1", out_buffer, NULL); //将文件内容通过out1发送到下一个节点
		free(out_buffer);
		//这里删除my8.txt文件
		sp_config_delete(storage, NULL, "my8.txt");
	} else {
		//读取失败
		LOGE(TAG, "Load config fail ret=%d", ret);
	}

	//这里将输入的数据保存到my8.txt
	sp_config_save(storage, NULL, "my8.txt", input_data, strlen(input_data));
}


void sp_config_test()
{
	SP_Storage handle = sp_storage_init(); //初始化存储
	if (handle == NULL) {
		LOGE(TAG, "sp storage init failed");
		return;
	}
	Sp_mq mq =  sp_mq_init();  //初始化一个mq
	sp_mq_register_callback(mq, mq_callback_config, handle); //注册mq回调
}

int test_config()
{
	
	LOGD(TAG, "test function starts");
	sp_config_test();

	while (1)
	{
		os_sleep(1);
	}
}
