
#include "sdk_utility.h" //包含LOGD,os_sleep等函数，用户可以不使用

#define TAG "MAIN_TEST"

extern int test_env();
extern int test_mq();
extern int test_storage();
extern int test_config();

#define TEST_MODE 1

int main(int argc, char **argv)
{
	LOGD(TAG, "test function starts");

#if TEST_MODE == 1
	test_env();
#endif

#if TEST_MODE == 2
	test_mq();
#endif

#if TEST_MODE == 3
	test_config();
#endif

#if TEST_MODE == 4
	test_storage();
#endif

	//不会运行到这里。
	LOGD(TAG, "Test End");
	while (1)
	{
		os_sleep(1);
	}
}
