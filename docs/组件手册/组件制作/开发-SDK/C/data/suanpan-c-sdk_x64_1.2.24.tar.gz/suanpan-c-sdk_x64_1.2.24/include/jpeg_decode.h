#ifndef __JPEG_DECODE__
#define __JPEG_DECODE__

#include "sdk_os.h"
//convert jpeg file to bmp file
__EXPORT int JPEG_To_BMP(char *in_buffer, int size,char **out_buffer);

#endif