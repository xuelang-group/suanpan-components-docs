#ifndef __SOCKETIO_CLIENT_H__
#define __SOCKETIO_CLIENT_H__


#include "sdk_os.h"

struct sio_payload {
    char *message;
    int length; //if 0. it is string message, if not 0, it is binary message
};


struct sio_reconnect {
    BOOL enable; //whether to reconnect automatically
    int attempts; //number of reconnection attempts before giving up
    int delay; //how long to initially wait before attempting a new reconnection, delay = delay + 1000ms every time
    int delay_max; //maximum amount of time to wait between reconnections
    int timeout; //connection timeout before a connect_error and connect_timeout events are emitted
};

typedef void (*SIO_Client_On_Event)(void *handle, char *namespace, char* event, 
                        struct sio_payload *payload,  int payload_len, void* user);

typedef void (*SIO_Client_On_Ack)(void* handle, char* namespace, char* event,
    struct sio_payload* payload, int payload_len, int message_id, void* user);


typedef void *SIO_Handle;

#define DEFAULT_URL "/socket.io/?EIO=3&transport=websocket"
#define DEFAULT_FINGERPRINT ""


struct sio_client_cb_param {
    SIO_Client_On_Event onevent;
    SIO_Client_On_Ack onack;
    void *user;
};


/**
* 初始化一个SocketIO客户端，填充参数
* @param[in]   host 域名，比如sp.xuelangyun.com.
* @param[in]   port 端口，比如90.
* @param[in]   url 子域名，比如"/socket.io/?EIO=3&transport=websocket"
* @param[in]   header_json 额外的握手头部信息 比如{"a":"b"}
* @param[in]   namespace 命令空间 比如/hardware
* @param[in]   reconnect 重连参数
* @retval  0  成功
* @retval  -1  错误，一般是因为文件不存在
*/
SIO_Handle SIO_Client_Init(char* host, int port, char* url,
    char* header_json, char* namespace,
    struct sio_reconnect reconnect);


/** 
* 开启一个SocketIO客户端
* @param[in]   callback 回调参数
* @retval  0  成功 
* @retval  -1  错误，一般是因为文件不存在
*/
int SIO_Client_Start(SIO_Handle handle, struct sio_client_cb_param* callback);

/** 
* 发送socketIO数据
* @param[in]   handle 句柄.通过打开SIO_Client_Start得到
* @param[in]   event 事件，发送的事件. 注意'connect', 'message' and 'disconnect' 这些是保留事件不能用
* @param[in]   data 字符串数据
* @param[in]   qos 消息的优先级
* @param[in]   namespace 命令空间 比如/hardware
* @retval  0  成功 
* @retval  -1  错误
*/
__EXPORT int SIO_Client_Emit(void *handle, char *event, 
                    char *data, int qos, 
                    BOOL need_callback, int *message_id, char *namespace);

/** 
* 发送socketIO数据
* @param[in]   handle 句柄.通过打开SIO_Client_Start得到
* @param[in]   event 事件，发送的事件. 注意'connect', 'message' and 'disconnect' 这些是保留事件不能用
* @param[in]   payload 负载，见struct sio_payload
* @param[in]   payload_num 负载的数量
* @param[in]   qos 消息的优先级
* @param[in]   need_callback 是否期望服务器反馈ACK数据
* @param[in]   message_id 如果期望服务器反馈ACK数据，ACK对应的ID
* @param[in]   namespace 命令空间 比如/hardware
* @retval  0  成功 
* @retval  -1  错误
*/
__EXPORT int SIO_Client_Emit_Ex(void *handle, char *event, 
                 struct sio_payload *payload, int payload_num, int qos,
                 BOOL need_callback, int *message_id, char *namespace);
/** 
* 停止一个socketio实例
* @param[in]   handle 句柄.通过打开SIO_Client_Start得到
* @retval  0  成功 
* @retval  -1  错误
*/
__EXPORT int SIO_Client_Close(SIO_Handle handle);

#endif
