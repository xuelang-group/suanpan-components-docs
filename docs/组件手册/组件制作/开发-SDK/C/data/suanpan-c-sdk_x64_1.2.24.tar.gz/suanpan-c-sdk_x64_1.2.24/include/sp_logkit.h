#ifndef __SP_LOGKIT_H__
#define __SP_LOGKIT_H__

#include "sdk_os.h"
__EXPORT void sp_logkit_init();
void sp_logkit_output();

#endif