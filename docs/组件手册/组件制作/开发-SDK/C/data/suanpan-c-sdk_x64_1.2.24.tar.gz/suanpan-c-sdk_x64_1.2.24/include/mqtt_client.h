#ifndef __MQTT_CLIENT__
#define __MQTT_CLIENT__



typedef int (*cmqtt_message_callback)(void* context, char* topic, int topic_len,char *message, int message_len);
typedef int (*cmqtt_disconnected)(void* context, char *reason);
typedef int (*cmqtt_connected)(void* context, char *reason);
typedef int (*cmqtt_message_sent_callback)(void* context); //消息被发送出去

struct cmqtt_callback {
    cmqtt_message_callback callback;
    cmqtt_disconnected disconnected;
    cmqtt_connected connected;
    cmqtt_message_sent_callback sent;
    void *param;
};

typedef void * CMQTT_Handle;

#include "sdk_os.h"

__EXPORT void* CMQTT_Init(char *host, int port,  char *clientid, struct cmqtt_callback *callback);
__EXPORT int CMQTT_Connect_Server(void* handle, char *username, char *password, int ssl_enable);
__EXPORT int CMQTT_Subscribe(void* handle, char *topic, int qos);
__EXPORT int CMQTT_Send_Binary_Data(void* handle, char *topic, char *buffer, int buffer_len, int qos);
__EXPORT int CMQTT_Send_Data(void* handle, char *topic, char *buffer, int qos);
__EXPORT int CMQTT_Deinit(void* handle);




void CMQTT_Test();

#endif
