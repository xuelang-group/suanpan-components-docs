#ifndef __BMP_ENCODE_H__
#define __BMP_ENCODE_H__

#define FMT_YUV420P 0
#define FMT_YV12 1

#include "sdk_os.h"
//BMP存储像素值的方式为从下至上，从左至右，紧随着文件头存储的字节为图像最下一行的数值，从左下角开始依次存储。

__EXPORT int bmp_header_size();//54
__EXPORT int bmp_header_add(unsigned char *buffer, int width, int height);

__EXPORT int bmp_get_width(char *buffer);
__EXPORT int bmp_get_height(char *buffer);

//用户自己malloc一次并传入rgb的buffer, 可以复用，用不着每一次malloc

__EXPORT int YUV420_To_BMP(unsigned char* yuv, unsigned char* rgb,
                    int width,  int height);

__EXPORT int YUV422_To_BMP(unsigned char *yuv, unsigned char *rgb,
                 int width,  int height);


__EXPORT int BMP_Resize_GD(char *buffer, char *out_buffer,
                int width, int height, 
                int target_width, int target_height);
__EXPORT int BMP_Resize_linear(char *buffer, char *out_buffer,
	            int width, int height, 
                int target_width, int target_height);

__EXPORT int bmp_to_npy(char* buffer, int bmp_header_offset, int width, int height, char** out_buffer, int* out_len);
__EXPORT int bmp_to_npy2(char* buffer, char** out_buffer, int* out_len, int reverse);


#endif