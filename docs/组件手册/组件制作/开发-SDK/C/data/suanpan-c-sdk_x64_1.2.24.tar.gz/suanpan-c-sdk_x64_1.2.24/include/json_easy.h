#ifndef _JSON_EASY_H_
#define _JSON_EASY_H_

#include "sdk_os.h"
#include <json-c/json.h>

#define Json struct json_object
#define Json_to_str(x) json_object_to_json_string_ext(x, JSON_C_TO_STRING_PLAIN )
#define Json_to_str_pretty(x) json_object_to_json_string_ext(x, JSON_C_TO_STRING_PRETTY )
#define Json_from_str json_tokener_parse
#define Json_free json_object_put
#define Json_new json_object_new_object
#define Json_str json_object_get_string
#define Json_int json_object_get_int
#define Json_array_new json_object_new_array
#define Json_array_length json_object_array_length
#define Json_array_get json_object_array_get_idx
#define Json_array_add json_object_array_add
#define Json_add_obj json_object_object_add

/** 
* 从某个子路径得到json的内容 
* @param[in]  o Json对象
* @param[in]  sub_path 子目录，比如 A.B[1].C
* @retval  char* Json字符串内容
* @retval  NULL   错误  
*/
__EXPORT char* Json_get_str(Json *o, char* sub_path);
/** 
* 从某个子路径得到json
* @param[in]  o Json对象
* @param[in]  sub_path 子目录，比如 A.B[1].C
* @retval  Json* 对象内容
* @retval  NULL   错误  
*/
__EXPORT Json* Json_get_obj(Json *o, char* sub_path);
/** 
* 从某个子路径得到json的int值
* @param[in]  o Json对象
* @param[in]  sub_path 子目录，比如 A.B[1].C
* @retval  int Json值
* @retval  NULL   错误  
*/
__EXPORT int Json_get_int(Json *o, char* path);

/** 
* 添加一个字符串定义到json对象 
* @param[in]  o Json对象
* @param[in]  key key
* @param[in]  str 字符串
* @retval  0 成功
* @retval  -1 失败  
*/
__EXPORT int Json_add_str(Json *o, char *key, char*str);

/** 
* 添加一个int定义到json对象 
* @param[in]  o Json对象
* @param[in]  key key
* @param[in]  val 值
* @retval  0 成功
* @retval  -1 失败  
*/
__EXPORT int Json_add_int(Json *o, char *key, int val);


#endif