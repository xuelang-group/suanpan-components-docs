#!/bin/sh

echo "Installing build tools"
apt-get install -y make git gcc g++ cmake curl netcat ncurses-dev scons unzip autoconf libtool intltool nasm swig bison python-dev gtk-doc-tools  pax-utils

echo "Installing dependent libraries"
# libusb-1.0-0-dev: firmata
# libasound2-dev: audio
# libturbojpeg0-dev: jpeg 
# libpng-dev : png
# libjson-c-dev : json
# libnanomsg-dev: nanomsg
# libczmq-dev : zmq
# libhiredis-dev: redis
# libcurl4-openssl-dev curl
# libmbedtls-dev: no use
# libapr1-dev libaprutil1-dev libmxml-dev  uuid-dev libssl-dev: aliyun oss
apt-get install -y \
  libapr1-dev libaprutil1-dev libmxml-dev uuid-dev

#echo "if ubuntu 16.04, please install cmake 3.13 or later, using cmake --version"
#cmake 3.13 install
#apt-get remove cmake
#./configure
#sudo make install
#ln -s /usr/local/bin/cmake /usr/bin/cmake    

# to debug, using 'lddtree foo' or 'lddtree -a foo'
