#ifndef __FILE_OPS_H__
#define __FILE_OPS_H__

#include "sdk_os.h"

/** 
* 得到某个文件的二进制大小 
* @param[in]  file_name 文件名
* @retval  size 文件大小
* @retval  0   错误  
*/
__EXPORT int File_Len(char* file_name);
/** 
* 读取某个文件，得到字符串形式的文件内容 
* @param[in]  file_name 文件名
* @retval  char* 文件的内容，需要在外面释放
* @retval  NULL   错误  
*/
__EXPORT char* File_Read_String(char* file_name);
/** 
* 向某个文件写入一个二进制buffer 
* @param[in]  file_name 文件名
* @param[in]  buffer 文件内容
* @param[in]  buffer_size 文件大小
* @retval  0 成功
* @retval  -1  失败  
*/
__EXPORT int File_Write(char *file_name, char* buffer, int buffer_size);
/** 
* 读取文件的内容，以二进制的形式返回 
* @param[in]  file_name 文件名
* @param[in]  buffer_out 文件内容
* @param[in]  size 文件大小
* @retval  0 成功
* @retval  -1  失败  
*/
__EXPORT int File_Read_Binary(char* file_name, char **buffer_out, int *size);
/** 
* 文件是否存在 
* @param[in]  file_name 文件名
* @retval  true/1 存在
* @retval  false/0  不存在  
*/
__EXPORT int File_Exists(const char* filename);
/** 
* 文件拷贝
* @param[in]  src 源头
* @param[in]  dest 目标
* @retval  0 成功
* @retval  -1  失败  
*/
__EXPORT int File_Copy(char* src, char* dest);
/** 
* 建立文件
* @param[in]  path 目录
* @param[in]  mode 模式
* @retval  0 成功
* @retval  -1  失败  
*/
__EXPORT int File_Mkdir(char *path, int mode);
/** 
* 替代文件中的内容
* @param[in]  filename_src 源文件
* @param[in]  filename_dst 目标文件
* @param[in]  orig_word 原文字
* @param[in]  replace_word 需要替代的文字
* @retval  0 成功
* @retval  -1  失败  
*/
__EXPORT int File_Replace_String(char *filename_src, char *filename_dst,
                char* orig_word, char *replace_word);
/** 
* 删除一个文件
* @param[in]  path 源文件
* @retval  0 成功
* @retval  -1  失败  
*/
__EXPORT int File_Delete(char *path);

/**
* 在文件尾部添加字符串
* @param[in]  file_name 源文件
* @param[in]  buffer 字符串内容
* @retval  0 成功
* @retval  -1  失败
*/
__EXPORT int File_Append_String(char* file_name, char* buffer);

#endif