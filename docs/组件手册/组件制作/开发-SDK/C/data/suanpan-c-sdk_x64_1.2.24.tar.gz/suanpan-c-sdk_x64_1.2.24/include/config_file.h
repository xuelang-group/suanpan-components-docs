/** 
* @file     config_file.h 
* @brief    ini数据结构操作接口和ini文件加载保存接口
* @details  此文件可以在内存里面操作ini数据结构，分为section和下面的key val对. 
*/  

#ifndef __CONFIG_FILE_H__
#define __CONFIG_FILE_H__

#include "sdk_list.h"
#include "sdk_os.h"

struct config_handle {
    struct list_head section_list; //list of config_section
    struct os_mutex mutex;
};



/** 
* 初始化config. 
* @retval  struct config_handle*  成功 
* @retval  NULL   错误  
*/
__EXPORT struct config_handle* Config_Init();


/** 
* 从ini buffer将数据结构加载到内存数据结构. 
* @param[in]  handle 文件句柄. 
* @param[in]  file_name 文件名.  
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Buffer_Load(void* handle, char *buffer);
/** 
* 将内存对象中的配置写入到ini buffer 
* @param[in]  handle 文件句柄. 
* @param[in]  file_name 文件名.  
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Buffer_Write(void *handle, char *buffer);
/** 
* 从ini文件将数据结构加载到内存数据结构. 
* @param[in]  handle 文件句柄. 
* @param[in]  file_name 文件名.  
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_File_Load(void* handle, char *file_name);
/** 
* 将内存对象中的配置写入到ini文件. 
* @param[in]  handle 文件句柄. 
* @param[in]  file_name 文件名.  
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_File_Write(void *handle, char *file_name);
/** 
* 释放配置内存对象
* @param[in]  handle 文件句柄. 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Close(void *handle);
/** 
* 是否存在对应section_key里面的key
* @param[in]  handle 文件句柄. 
* @param[in]  section_key 目录名称.  
* @param[in]  key 字段名称.  
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Exists(void *handle, char *section_key, char *key);
/** 
* 是否存在一个目录
* @param[in]  handle 文件句柄. 
* @param[in]  section_key 目录名称.  
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Section_Exists(void *handle, char *section_key);
/** 
* 得到某section中，某个key对应的值, 内存不需要释放
* @param[in]  handle 文件句柄. 
* @param[in]  section_key 目录名称. 
* @param[in]  key 字段名称. 
* @param[out] val 获取的值，外部不需要释放. 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Get(void *handle, char *section_key, char *key, char **val);
/** 
* 得到某section中，某个key对应的值，内存不需要释放
* @param[in]  handle 文件句柄. 
* @param[in]  section_key 目录名称. 
* @param[in]  key 字段名称. 
* @retval  值  成功 
* @retval  NULL   错误  
*/
__EXPORT char* Config_Get_Ptr(void *handle, char *section_key, char *key);
/** 
* 向section中，添加一个key-val对
* @param[in]  handle 文件句柄. 
* @param[in]  section_key 目录名称. 
* @param[in]  key 字段名称. 
* @param[in] val 字段值
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Add(void *handle, char *section_key, char *key, char *val);
/** 
* 添加一个section
* @param[in]  handle 文件句柄. 
* @param[in]  section_key 目录名称. 
* @param[in]  key 字段名称. 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Add_Section(void *handle, char *section_key);
/** 
* 向section中，更新一个key-val对
* @param[in]  handle 文件句柄. 
* @param[in]  section_key 目录名称. 
* @param[in]  key 字段名称. 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Update(void *handle, char *section_key, char *key, char *val);
/** 
* 向section中，删除一个key-val对
* @param[in]  handle 文件句柄. 
* @param[in]  section_key 目录名称. 
* @param[in]  key 字段名称. 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Delete_Entry(void *handle, char *section_key, char *key);
/** 
* 删除一个section
* @param[in]  handle 文件句柄. 
* @param[in]  section_key 目录名称. 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Delete_Section(void *handle, char *section_key);
/** 
* 删除所有的section，包括section下面的所有key-val
* @param[in]  handle 文件句柄. 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Delete_All(void* handle);
/** 
* 打印所有的section，包括section下面的所有key-val
* @param[in]  handle 文件句柄. 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Dump(void *handle);
/** 
* 将一个section下面的key-val以json格式给出
* 获取的数据格式：
* [ {"key":"123", "val":"456"},
*   {"key":"abc", "val":"789"},
*   {"key":"DEF", "val":"999"},
* ]
* @param[in]  handle 文件句柄. 
* @param[in]  section_key 目录名称. 
* @param[out]  json 得到的json格式字符串. 外部需要释放此内存
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Dump_Entry_Json(void *handle, char *section_name, char **json);
/** 
* 将所有section以json给出
* 获取的数据格式：
* [ "ABCCDDEE", "FF12356VVV",]
* @param[in]  handle 文件句柄. 
* @param[out]  json 得到的json格式字符串. 外部需要释放此内存
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Dump_Section_Json(void *handle, char **json);
/** 
* 得到某section下面所有的key数量, Config_Get_Count 更新为 Config_Item_Get_Count
* @param[in]  handle 文件句柄. 
* @param[in]  section_key 目录名称. 
* @retval  0  成功 
* @retval  -1   错误  
*/
__EXPORT int Config_Get_Count(void *handle, char *section_name);
__EXPORT int Config_Item_Get_Count(void *handle, char *section_name);

/** 
* 得到所有section数量（未验证）
* @param[in]  handle 文件句柄. 
* @retval  section数量  成功 
* @retval  0   错误
*/
__EXPORT int Config_Section_Get_Count(void *handle);

/** 
* 得到第n个section的名称（未验证）
* @param[in]  handle 文件句柄. 
* @param[in]  index 第几个. 
* @retval  名称  成功 
* @retval  NULL   错误  
*/
__EXPORT char* Config_Section_Get_At(void *handle, int index);

/** 
* 得到第n个Item的key（未验证）
* @param[in]  handle 文件句柄. 
* @param[in]  section_key section名称. 
* @param[in]  index 第几个. 
* @retval  名称  成功 
* @retval  NULL   错误  
*/
__EXPORT char* Config_Item_Get_Key_At(void *handle, char *section_key, int index);


/** 
* 得到第n个Item的value（未验证）
* @param[in]  handle 文件句柄. 
* @param[in]  section_key section名称. 
* @param[in]  index 第几个. 
* @retval  名称  成功 
* @retval  NULL   错误  
*/
__EXPORT char* Config_Item_Get_Val_At(void *handle, char *section_key, int index);



#endif
