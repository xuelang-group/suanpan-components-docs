#ifndef __KAFKA_PRODUCER__
#define __KAFKA_PRODUCER__

#include "sdk_os.h"

#define kafka_producer_send kafka_pruducer_send

__EXPORT void* kafka_producer_new(char* brokers);
__EXPORT int kafka_pruducer_send(void *handle, char *topic, char *data, int length);
__EXPORT int kafka_producer_destroy(void *handle);

#endif