#ifndef __SENSORCHANNEL_API__
#define __SENSORCHANNEL_API__


enum gpio_mode {
    GPIO_MODE_OUT = 0,
    GPIO_MODE_IN,
    //GPIO_MODE_PWM,
};

enum analog_mode {
    ANALOG_MODE_IN = 0,
    ANALOG_MODE_OUT,
};


typedef void *sca_handle;

typedef void (*gpio_callback_func)(int gpio_pin, int gpio_val);
typedef int (*uart_callback_func)(char *buffer, int length);

struct gpio_callback;

sca_handle sca_open(char *channel_name, char* config_file);
int sca_close(sca_handle handle);

int sca_gpio_init(sca_handle handle, int pin, int mode);
int sca_gpio_write(sca_handle handle, int pin, int value);
int sca_gpio_read(sca_handle handle, int pin, int *value);
int sca_gpio_register_cb(sca_handle handle, gpio_callback_func cb); //when gpio_toggled, callback

int sca_analog_init(sca_handle handle, int pin, int mode);
int sca_analog_write(sca_handle handle, int pin, int value);
int sca_analog_read(sca_handle handle, int pin, int *value);

int sca_pwm_init(sca_handle handle, int pin, int frequency);
int sca_pwm_write(sca_handle handle, int pin, int duty_cycle); //0-255

int sca_servo_init(sca_handle handle, int pin);
int sca_servo_write(sca_handle handle, int pin, int angle); //0-180

int sca_uart_open(sca_handle handle, int uart_idx, int baudrate);
int sca_uart_close(sca_handle handle, int uart_idx);
int sca_uart_write(sca_handle handle, int uart_idx, char *buffer, int length);
int sca_uart_read(sca_handle handle, int uart_idx, char *buffer, int len);
int sca_uart_register_cb(sca_handle handle, int uart_idx, uart_callback_func cb);

int sca_i2c_init(sca_handle handle, int sck_pin, int sda_pin, int delay);
int sca_i2c_write(sca_handle handle, int address, char *buffer, int size);
int sca_i2c_read_register(sca_handle handle, int address, int register_address, char *buffer, int size);
int sca_i2c_write_register(sca_handle handle, int address, int register_address, char *buffer, int size);
int sca_i2c_read(sca_handle handle, int address, char *buffer, int size);
int sca_i2c_ping(sca_handle handle, int address);

int sca_spi_init(void* handle, int spi_index, int frequency, int cpol, int cpha);
int sca_spi_write(void* handle, char *buffer, int size);
int sca_spi_read(void* handle, char *buffer, int size);
int sca_spi_enable_chip(void* handle, int enable);
int sca_spi_write_read(void* handle, char *inbuffer, int insize, char *outbuffer, int outsize);
int sca_poll(sca_handle handle); //keep alive

void Sensor_Channel_module_Init();

void Sensor_Channel_module_register_firmata();
void Sensor_Channel_module_register_FT232H();
void Sensor_Channel_module_register_onboard();




#endif