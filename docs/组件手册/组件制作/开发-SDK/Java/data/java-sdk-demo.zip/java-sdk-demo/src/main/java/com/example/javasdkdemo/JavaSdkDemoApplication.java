package com.example.javasdkdemo;

import com.xuelang.mqstream.handler.annotation.EnableComponentConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@EnableComponentConfig
@SpringBootApplication
public class JavaSdkDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(JavaSdkDemoApplication.class, args);
    }

}
