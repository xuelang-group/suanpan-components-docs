package com.example.javasdkdemo.business;

import com.xuelang.mqstream.handler.annotation.BussinessListener;
import com.xuelang.mqstream.handler.annotation.BussinessListenerMapping;
import com.xuelang.mqstream.message.arguments.CommonType;
import com.xuelang.service.logkit.EventLogger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@BussinessListener
@Service
@Slf4j
public class DealMsgService {

    @Autowired
    private  EventLogger eventLogger;

    /**
     * CommonType类型消息的处理方式
     *
     * @param commonType 收到的消息
     * @return 返回的消息
     */
    @BussinessListenerMapping(input = "in1", targets = {"out1"})
    public Object dealCommonTypeMsg1(CommonType commonType) {
        Object in1 = commonType.getMessage().get("in1");
        eventLogger.info("get msg :  {} " , in1.toString());

        //todo 在此处处理in1s

        //返回消息至下一个节点
        return "SUCCESS:" + commonType.getMessage().get("in1");
    }

    @BussinessListenerMapping(input = "in2", targets = {"out2"})
    public Object dealCommonTypeMsg2(CommonType commonType) {

        //todo 在此处处理in2

        return "success";
    }

}
